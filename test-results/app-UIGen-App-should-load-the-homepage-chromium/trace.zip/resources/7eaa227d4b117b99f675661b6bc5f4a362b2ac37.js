(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_1377b29c._.js",
  "static/chunks/node_modules_tailwind-merge_dist_bundle-mjs_mjs_b854acb4._.js",
  "static/chunks/node_modules_zod_dist_esm_a4e0c589._.js",
  "static/chunks/node_modules_micromark-core-commonmark_dev_lib_36a4b45d._.js",
  "static/chunks/node_modules_@babel_standalone_babel_832e54e3.js",
  "static/chunks/node_modules_@ai-sdk_2665e7c3._.js",
  "static/chunks/node_modules_@radix-ui_21f5b883._.js",
  "static/chunks/node_modules_@floating-ui_9ec1fa39._.js",
  "static/chunks/node_modules_ef2296ee._.js"
],
    source: "dynamic"
});
