(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/node_modules/@ai-sdk/provider/dist/index.mjs [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
// src/errors/ai-sdk-error.ts
__turbopack_context__.s({
    "AISDKError": (()=>AISDKError),
    "APICallError": (()=>APICallError),
    "EmptyResponseBodyError": (()=>EmptyResponseBodyError),
    "InvalidArgumentError": (()=>InvalidArgumentError),
    "InvalidPromptError": (()=>InvalidPromptError),
    "InvalidResponseDataError": (()=>InvalidResponseDataError),
    "JSONParseError": (()=>JSONParseError),
    "LoadAPIKeyError": (()=>LoadAPIKeyError),
    "LoadSettingError": (()=>LoadSettingError),
    "NoContentGeneratedError": (()=>NoContentGeneratedError),
    "NoSuchModelError": (()=>NoSuchModelError),
    "TooManyEmbeddingValuesForCallError": (()=>TooManyEmbeddingValuesForCallError),
    "TypeValidationError": (()=>TypeValidationError),
    "UnsupportedFunctionalityError": (()=>UnsupportedFunctionalityError),
    "getErrorMessage": (()=>getErrorMessage),
    "isJSONArray": (()=>isJSONArray),
    "isJSONObject": (()=>isJSONObject),
    "isJSONValue": (()=>isJSONValue)
});
var marker = "vercel.ai.error";
var symbol = Symbol.for(marker);
var _a;
var _AISDKError = class _AISDKError extends Error {
    /**
   * Creates an AI SDK Error.
   *
   * @param {Object} params - The parameters for creating the error.
   * @param {string} params.name - The name of the error.
   * @param {string} params.message - The error message.
   * @param {unknown} [params.cause] - The underlying cause of the error.
   */ constructor({ name: name14, message, cause }){
        super(message);
        this[_a] = true;
        this.name = name14;
        this.cause = cause;
    }
    /**
   * Checks if the given error is an AI SDK Error.
   * @param {unknown} error - The error to check.
   * @returns {boolean} True if the error is an AI SDK Error, false otherwise.
   */ static isInstance(error) {
        return _AISDKError.hasMarker(error, marker);
    }
    static hasMarker(error, marker15) {
        const markerSymbol = Symbol.for(marker15);
        return error != null && typeof error === "object" && markerSymbol in error && typeof error[markerSymbol] === "boolean" && error[markerSymbol] === true;
    }
};
_a = symbol;
var AISDKError = _AISDKError;
// src/errors/api-call-error.ts
var name = "AI_APICallError";
var marker2 = `vercel.ai.error.${name}`;
var symbol2 = Symbol.for(marker2);
var _a2;
var APICallError = class extends AISDKError {
    constructor({ message, url, requestBodyValues, statusCode, responseHeaders, responseBody, cause, isRetryable = statusCode != null && (statusCode === 408 || // request timeout
    statusCode === 409 || // conflict
    statusCode === 429 || // too many requests
    statusCode >= 500), // server error
    data }){
        super({
            name,
            message,
            cause
        });
        this[_a2] = true;
        this.url = url;
        this.requestBodyValues = requestBodyValues;
        this.statusCode = statusCode;
        this.responseHeaders = responseHeaders;
        this.responseBody = responseBody;
        this.isRetryable = isRetryable;
        this.data = data;
    }
    static isInstance(error) {
        return AISDKError.hasMarker(error, marker2);
    }
};
_a2 = symbol2;
// src/errors/empty-response-body-error.ts
var name2 = "AI_EmptyResponseBodyError";
var marker3 = `vercel.ai.error.${name2}`;
var symbol3 = Symbol.for(marker3);
var _a3;
var EmptyResponseBodyError = class extends AISDKError {
    // used in isInstance
    constructor({ message = "Empty response body" } = {}){
        super({
            name: name2,
            message
        });
        this[_a3] = true;
    }
    static isInstance(error) {
        return AISDKError.hasMarker(error, marker3);
    }
};
_a3 = symbol3;
// src/errors/get-error-message.ts
function getErrorMessage(error) {
    if (error == null) {
        return "unknown error";
    }
    if (typeof error === "string") {
        return error;
    }
    if (error instanceof Error) {
        return error.message;
    }
    return JSON.stringify(error);
}
// src/errors/invalid-argument-error.ts
var name3 = "AI_InvalidArgumentError";
var marker4 = `vercel.ai.error.${name3}`;
var symbol4 = Symbol.for(marker4);
var _a4;
var InvalidArgumentError = class extends AISDKError {
    constructor({ message, cause, argument }){
        super({
            name: name3,
            message,
            cause
        });
        this[_a4] = true;
        this.argument = argument;
    }
    static isInstance(error) {
        return AISDKError.hasMarker(error, marker4);
    }
};
_a4 = symbol4;
// src/errors/invalid-prompt-error.ts
var name4 = "AI_InvalidPromptError";
var marker5 = `vercel.ai.error.${name4}`;
var symbol5 = Symbol.for(marker5);
var _a5;
var InvalidPromptError = class extends AISDKError {
    constructor({ prompt, message, cause }){
        super({
            name: name4,
            message: `Invalid prompt: ${message}`,
            cause
        });
        this[_a5] = true;
        this.prompt = prompt;
    }
    static isInstance(error) {
        return AISDKError.hasMarker(error, marker5);
    }
};
_a5 = symbol5;
// src/errors/invalid-response-data-error.ts
var name5 = "AI_InvalidResponseDataError";
var marker6 = `vercel.ai.error.${name5}`;
var symbol6 = Symbol.for(marker6);
var _a6;
var InvalidResponseDataError = class extends AISDKError {
    constructor({ data, message = `Invalid response data: ${JSON.stringify(data)}.` }){
        super({
            name: name5,
            message
        });
        this[_a6] = true;
        this.data = data;
    }
    static isInstance(error) {
        return AISDKError.hasMarker(error, marker6);
    }
};
_a6 = symbol6;
// src/errors/json-parse-error.ts
var name6 = "AI_JSONParseError";
var marker7 = `vercel.ai.error.${name6}`;
var symbol7 = Symbol.for(marker7);
var _a7;
var JSONParseError = class extends AISDKError {
    constructor({ text, cause }){
        super({
            name: name6,
            message: `JSON parsing failed: Text: ${text}.
Error message: ${getErrorMessage(cause)}`,
            cause
        });
        this[_a7] = true;
        this.text = text;
    }
    static isInstance(error) {
        return AISDKError.hasMarker(error, marker7);
    }
};
_a7 = symbol7;
// src/errors/load-api-key-error.ts
var name7 = "AI_LoadAPIKeyError";
var marker8 = `vercel.ai.error.${name7}`;
var symbol8 = Symbol.for(marker8);
var _a8;
var LoadAPIKeyError = class extends AISDKError {
    // used in isInstance
    constructor({ message }){
        super({
            name: name7,
            message
        });
        this[_a8] = true;
    }
    static isInstance(error) {
        return AISDKError.hasMarker(error, marker8);
    }
};
_a8 = symbol8;
// src/errors/load-setting-error.ts
var name8 = "AI_LoadSettingError";
var marker9 = `vercel.ai.error.${name8}`;
var symbol9 = Symbol.for(marker9);
var _a9;
var LoadSettingError = class extends AISDKError {
    // used in isInstance
    constructor({ message }){
        super({
            name: name8,
            message
        });
        this[_a9] = true;
    }
    static isInstance(error) {
        return AISDKError.hasMarker(error, marker9);
    }
};
_a9 = symbol9;
// src/errors/no-content-generated-error.ts
var name9 = "AI_NoContentGeneratedError";
var marker10 = `vercel.ai.error.${name9}`;
var symbol10 = Symbol.for(marker10);
var _a10;
var NoContentGeneratedError = class extends AISDKError {
    // used in isInstance
    constructor({ message = "No content generated." } = {}){
        super({
            name: name9,
            message
        });
        this[_a10] = true;
    }
    static isInstance(error) {
        return AISDKError.hasMarker(error, marker10);
    }
};
_a10 = symbol10;
// src/errors/no-such-model-error.ts
var name10 = "AI_NoSuchModelError";
var marker11 = `vercel.ai.error.${name10}`;
var symbol11 = Symbol.for(marker11);
var _a11;
var NoSuchModelError = class extends AISDKError {
    constructor({ errorName = name10, modelId, modelType, message = `No such ${modelType}: ${modelId}` }){
        super({
            name: errorName,
            message
        });
        this[_a11] = true;
        this.modelId = modelId;
        this.modelType = modelType;
    }
    static isInstance(error) {
        return AISDKError.hasMarker(error, marker11);
    }
};
_a11 = symbol11;
// src/errors/too-many-embedding-values-for-call-error.ts
var name11 = "AI_TooManyEmbeddingValuesForCallError";
var marker12 = `vercel.ai.error.${name11}`;
var symbol12 = Symbol.for(marker12);
var _a12;
var TooManyEmbeddingValuesForCallError = class extends AISDKError {
    constructor(options){
        super({
            name: name11,
            message: `Too many values for a single embedding call. The ${options.provider} model "${options.modelId}" can only embed up to ${options.maxEmbeddingsPerCall} values per call, but ${options.values.length} values were provided.`
        });
        this[_a12] = true;
        this.provider = options.provider;
        this.modelId = options.modelId;
        this.maxEmbeddingsPerCall = options.maxEmbeddingsPerCall;
        this.values = options.values;
    }
    static isInstance(error) {
        return AISDKError.hasMarker(error, marker12);
    }
};
_a12 = symbol12;
// src/errors/type-validation-error.ts
var name12 = "AI_TypeValidationError";
var marker13 = `vercel.ai.error.${name12}`;
var symbol13 = Symbol.for(marker13);
var _a13;
var _TypeValidationError = class _TypeValidationError extends AISDKError {
    constructor({ value, cause }){
        super({
            name: name12,
            message: `Type validation failed: Value: ${JSON.stringify(value)}.
Error message: ${getErrorMessage(cause)}`,
            cause
        });
        this[_a13] = true;
        this.value = value;
    }
    static isInstance(error) {
        return AISDKError.hasMarker(error, marker13);
    }
    /**
   * Wraps an error into a TypeValidationError.
   * If the cause is already a TypeValidationError with the same value, it returns the cause.
   * Otherwise, it creates a new TypeValidationError.
   *
   * @param {Object} params - The parameters for wrapping the error.
   * @param {unknown} params.value - The value that failed validation.
   * @param {unknown} params.cause - The original error or cause of the validation failure.
   * @returns {TypeValidationError} A TypeValidationError instance.
   */ static wrap({ value, cause }) {
        return _TypeValidationError.isInstance(cause) && cause.value === value ? cause : new _TypeValidationError({
            value,
            cause
        });
    }
};
_a13 = symbol13;
var TypeValidationError = _TypeValidationError;
// src/errors/unsupported-functionality-error.ts
var name13 = "AI_UnsupportedFunctionalityError";
var marker14 = `vercel.ai.error.${name13}`;
var symbol14 = Symbol.for(marker14);
var _a14;
var UnsupportedFunctionalityError = class extends AISDKError {
    constructor({ functionality, message = `'${functionality}' functionality not supported.` }){
        super({
            name: name13,
            message
        });
        this[_a14] = true;
        this.functionality = functionality;
    }
    static isInstance(error) {
        return AISDKError.hasMarker(error, marker14);
    }
};
_a14 = symbol14;
// src/json-value/is-json.ts
function isJSONValue(value) {
    if (value === null || typeof value === "string" || typeof value === "number" || typeof value === "boolean") {
        return true;
    }
    if (Array.isArray(value)) {
        return value.every(isJSONValue);
    }
    if (typeof value === "object") {
        return Object.entries(value).every(([key, val])=>typeof key === "string" && isJSONValue(val));
    }
    return false;
}
function isJSONArray(value) {
    return Array.isArray(value) && value.every(isJSONValue);
}
function isJSONObject(value) {
    return value != null && typeof value === "object" && Object.entries(value).every(([key, val])=>typeof key === "string" && isJSONValue(val));
}
;
 //# sourceMappingURL=index.mjs.map
}}),
"[project]/node_modules/@ai-sdk/provider-utils/dist/index.mjs [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
// src/combine-headers.ts
__turbopack_context__.s({
    "asValidator": (()=>asValidator),
    "combineHeaders": (()=>combineHeaders),
    "convertAsyncIteratorToReadableStream": (()=>convertAsyncIteratorToReadableStream),
    "convertBase64ToUint8Array": (()=>convertBase64ToUint8Array),
    "convertUint8ArrayToBase64": (()=>convertUint8ArrayToBase64),
    "createBinaryResponseHandler": (()=>createBinaryResponseHandler),
    "createEventSourceParserStream": (()=>createEventSourceParserStream),
    "createEventSourceResponseHandler": (()=>createEventSourceResponseHandler),
    "createIdGenerator": (()=>createIdGenerator),
    "createJsonErrorResponseHandler": (()=>createJsonErrorResponseHandler),
    "createJsonResponseHandler": (()=>createJsonResponseHandler),
    "createJsonStreamResponseHandler": (()=>createJsonStreamResponseHandler),
    "createStatusCodeErrorResponseHandler": (()=>createStatusCodeErrorResponseHandler),
    "delay": (()=>delay),
    "extractResponseHeaders": (()=>extractResponseHeaders),
    "generateId": (()=>generateId),
    "getErrorMessage": (()=>getErrorMessage),
    "getFromApi": (()=>getFromApi),
    "isAbortError": (()=>isAbortError),
    "isParsableJson": (()=>isParsableJson),
    "isValidator": (()=>isValidator),
    "loadApiKey": (()=>loadApiKey),
    "loadOptionalSetting": (()=>loadOptionalSetting),
    "loadSetting": (()=>loadSetting),
    "parseJSON": (()=>parseJSON),
    "parseProviderOptions": (()=>parseProviderOptions),
    "postFormDataToApi": (()=>postFormDataToApi),
    "postJsonToApi": (()=>postJsonToApi),
    "postToApi": (()=>postToApi),
    "removeUndefinedEntries": (()=>removeUndefinedEntries),
    "resolve": (()=>resolve),
    "safeParseJSON": (()=>safeParseJSON),
    "safeValidateTypes": (()=>safeValidateTypes),
    "validateTypes": (()=>validateTypes),
    "validator": (()=>validator),
    "validatorSymbol": (()=>validatorSymbol),
    "withoutTrailingSlash": (()=>withoutTrailingSlash),
    "zodValidator": (()=>zodValidator)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
// src/generate-id.ts
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@ai-sdk/provider/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$nanoid$2f$non$2d$secure$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/nanoid/non-secure/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$secure$2d$json$2d$parse$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/secure-json-parse/index.js [app-client] (ecmascript)");
function combineHeaders(...headers) {
    return headers.reduce((combinedHeaders, currentHeaders)=>({
            ...combinedHeaders,
            ...currentHeaders != null ? currentHeaders : {}
        }), {});
}
// src/convert-async-iterator-to-readable-stream.ts
function convertAsyncIteratorToReadableStream(iterator) {
    return new ReadableStream({
        /**
     * Called when the consumer wants to pull more data from the stream.
     *
     * @param {ReadableStreamDefaultController<T>} controller - The controller to enqueue data into the stream.
     * @returns {Promise<void>}
     */ async pull (controller) {
            try {
                const { value, done } = await iterator.next();
                if (done) {
                    controller.close();
                } else {
                    controller.enqueue(value);
                }
            } catch (error) {
                controller.error(error);
            }
        },
        /**
     * Called when the consumer cancels the stream.
     */ cancel () {}
    });
}
// src/delay.ts
async function delay(delayInMs) {
    return delayInMs == null ? Promise.resolve() : new Promise((resolve2)=>setTimeout(resolve2, delayInMs));
}
// src/event-source-parser-stream.ts
function createEventSourceParserStream() {
    let buffer = "";
    let event = void 0;
    let data = [];
    let lastEventId = void 0;
    let retry = void 0;
    function parseLine(line, controller) {
        if (line === "") {
            dispatchEvent(controller);
            return;
        }
        if (line.startsWith(":")) {
            return;
        }
        const colonIndex = line.indexOf(":");
        if (colonIndex === -1) {
            handleField(line, "");
            return;
        }
        const field = line.slice(0, colonIndex);
        const valueStart = colonIndex + 1;
        const value = valueStart < line.length && line[valueStart] === " " ? line.slice(valueStart + 1) : line.slice(valueStart);
        handleField(field, value);
    }
    function dispatchEvent(controller) {
        if (data.length > 0) {
            controller.enqueue({
                event,
                data: data.join("\n"),
                id: lastEventId,
                retry
            });
            data = [];
            event = void 0;
            retry = void 0;
        }
    }
    function handleField(field, value) {
        switch(field){
            case "event":
                event = value;
                break;
            case "data":
                data.push(value);
                break;
            case "id":
                lastEventId = value;
                break;
            case "retry":
                const parsedRetry = parseInt(value, 10);
                if (!isNaN(parsedRetry)) {
                    retry = parsedRetry;
                }
                break;
        }
    }
    return new TransformStream({
        transform (chunk, controller) {
            const { lines, incompleteLine } = splitLines(buffer, chunk);
            buffer = incompleteLine;
            for(let i = 0; i < lines.length; i++){
                parseLine(lines[i], controller);
            }
        },
        flush (controller) {
            parseLine(buffer, controller);
            dispatchEvent(controller);
        }
    });
}
function splitLines(buffer, chunk) {
    const lines = [];
    let currentLine = buffer;
    for(let i = 0; i < chunk.length;){
        const char = chunk[i++];
        if (char === "\n") {
            lines.push(currentLine);
            currentLine = "";
        } else if (char === "\r") {
            lines.push(currentLine);
            currentLine = "";
            if (chunk[i] === "\n") {
                i++;
            }
        } else {
            currentLine += char;
        }
    }
    return {
        lines,
        incompleteLine: currentLine
    };
}
// src/extract-response-headers.ts
function extractResponseHeaders(response) {
    const headers = {};
    response.headers.forEach((value, key)=>{
        headers[key] = value;
    });
    return headers;
}
;
;
var createIdGenerator = ({ prefix, size: defaultSize = 16, alphabet = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz", separator = "-" } = {})=>{
    const generator = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$nanoid$2f$non$2d$secure$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["customAlphabet"])(alphabet, defaultSize);
    if (prefix == null) {
        return generator;
    }
    if (alphabet.includes(separator)) {
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InvalidArgumentError"]({
            argument: "separator",
            message: `The separator "${separator}" must not be part of the alphabet "${alphabet}".`
        });
    }
    return (size)=>`${prefix}${separator}${generator(size)}`;
};
var generateId = createIdGenerator();
// src/get-error-message.ts
function getErrorMessage(error) {
    if (error == null) {
        return "unknown error";
    }
    if (typeof error === "string") {
        return error;
    }
    if (error instanceof Error) {
        return error.message;
    }
    return JSON.stringify(error);
}
;
// src/remove-undefined-entries.ts
function removeUndefinedEntries(record) {
    return Object.fromEntries(Object.entries(record).filter(([_key, value])=>value != null));
}
// src/is-abort-error.ts
function isAbortError(error) {
    return error instanceof Error && (error.name === "AbortError" || error.name === "TimeoutError");
}
// src/get-from-api.ts
var getOriginalFetch = ()=>globalThis.fetch;
var getFromApi = async ({ url, headers = {}, successfulResponseHandler, failedResponseHandler, abortSignal, fetch = getOriginalFetch() })=>{
    try {
        const response = await fetch(url, {
            method: "GET",
            headers: removeUndefinedEntries(headers),
            signal: abortSignal
        });
        const responseHeaders = extractResponseHeaders(response);
        if (!response.ok) {
            let errorInformation;
            try {
                errorInformation = await failedResponseHandler({
                    response,
                    url,
                    requestBodyValues: {}
                });
            } catch (error) {
                if (isAbortError(error) || __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["APICallError"].isInstance(error)) {
                    throw error;
                }
                throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["APICallError"]({
                    message: "Failed to process error response",
                    cause: error,
                    statusCode: response.status,
                    url,
                    responseHeaders,
                    requestBodyValues: {}
                });
            }
            throw errorInformation.value;
        }
        try {
            return await successfulResponseHandler({
                response,
                url,
                requestBodyValues: {}
            });
        } catch (error) {
            if (error instanceof Error) {
                if (isAbortError(error) || __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["APICallError"].isInstance(error)) {
                    throw error;
                }
            }
            throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["APICallError"]({
                message: "Failed to process successful response",
                cause: error,
                statusCode: response.status,
                url,
                responseHeaders,
                requestBodyValues: {}
            });
        }
    } catch (error) {
        if (isAbortError(error)) {
            throw error;
        }
        if (error instanceof TypeError && error.message === "fetch failed") {
            const cause = error.cause;
            if (cause != null) {
                throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["APICallError"]({
                    message: `Cannot connect to API: ${cause.message}`,
                    cause,
                    url,
                    isRetryable: true,
                    requestBodyValues: {}
                });
            }
        }
        throw error;
    }
};
;
function loadApiKey({ apiKey, environmentVariableName, apiKeyParameterName = "apiKey", description }) {
    if (typeof apiKey === "string") {
        return apiKey;
    }
    if (apiKey != null) {
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LoadAPIKeyError"]({
            message: `${description} API key must be a string.`
        });
    }
    if (typeof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"] === "undefined") {
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LoadAPIKeyError"]({
            message: `${description} API key is missing. Pass it using the '${apiKeyParameterName}' parameter. Environment variables is not supported in this environment.`
        });
    }
    apiKey = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env[environmentVariableName];
    if (apiKey == null) {
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LoadAPIKeyError"]({
            message: `${description} API key is missing. Pass it using the '${apiKeyParameterName}' parameter or the ${environmentVariableName} environment variable.`
        });
    }
    if (typeof apiKey !== "string") {
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LoadAPIKeyError"]({
            message: `${description} API key must be a string. The value of the ${environmentVariableName} environment variable is not a string.`
        });
    }
    return apiKey;
}
// src/load-optional-setting.ts
function loadOptionalSetting({ settingValue, environmentVariableName }) {
    if (typeof settingValue === "string") {
        return settingValue;
    }
    if (settingValue != null || typeof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"] === "undefined") {
        return void 0;
    }
    settingValue = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env[environmentVariableName];
    if (settingValue == null || typeof settingValue !== "string") {
        return void 0;
    }
    return settingValue;
}
;
function loadSetting({ settingValue, environmentVariableName, settingName, description }) {
    if (typeof settingValue === "string") {
        return settingValue;
    }
    if (settingValue != null) {
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LoadSettingError"]({
            message: `${description} setting must be a string.`
        });
    }
    if (typeof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"] === "undefined") {
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LoadSettingError"]({
            message: `${description} setting is missing. Pass it using the '${settingName}' parameter. Environment variables is not supported in this environment.`
        });
    }
    settingValue = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env[environmentVariableName];
    if (settingValue == null) {
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LoadSettingError"]({
            message: `${description} setting is missing. Pass it using the '${settingName}' parameter or the ${environmentVariableName} environment variable.`
        });
    }
    if (typeof settingValue !== "string") {
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LoadSettingError"]({
            message: `${description} setting must be a string. The value of the ${environmentVariableName} environment variable is not a string.`
        });
    }
    return settingValue;
}
;
;
;
// src/validator.ts
var validatorSymbol = Symbol.for("vercel.ai.validator");
function validator(validate) {
    return {
        [validatorSymbol]: true,
        validate
    };
}
function isValidator(value) {
    return typeof value === "object" && value !== null && validatorSymbol in value && value[validatorSymbol] === true && "validate" in value;
}
function asValidator(value) {
    return isValidator(value) ? value : zodValidator(value);
}
function zodValidator(zodSchema) {
    return validator((value)=>{
        const result = zodSchema.safeParse(value);
        return result.success ? {
            success: true,
            value: result.data
        } : {
            success: false,
            error: result.error
        };
    });
}
// src/validate-types.ts
function validateTypes({ value, schema: inputSchema }) {
    const result = safeValidateTypes({
        value,
        schema: inputSchema
    });
    if (!result.success) {
        throw __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TypeValidationError"].wrap({
            value,
            cause: result.error
        });
    }
    return result.value;
}
function safeValidateTypes({ value, schema }) {
    const validator2 = asValidator(schema);
    try {
        if (validator2.validate == null) {
            return {
                success: true,
                value
            };
        }
        const result = validator2.validate(value);
        if (result.success) {
            return result;
        }
        return {
            success: false,
            error: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TypeValidationError"].wrap({
                value,
                cause: result.error
            })
        };
    } catch (error) {
        return {
            success: false,
            error: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TypeValidationError"].wrap({
                value,
                cause: error
            })
        };
    }
}
// src/parse-json.ts
function parseJSON({ text, schema }) {
    try {
        const value = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$secure$2d$json$2d$parse$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].parse(text);
        if (schema == null) {
            return value;
        }
        return validateTypes({
            value,
            schema
        });
    } catch (error) {
        if (__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["JSONParseError"].isInstance(error) || __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TypeValidationError"].isInstance(error)) {
            throw error;
        }
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["JSONParseError"]({
            text,
            cause: error
        });
    }
}
function safeParseJSON({ text, schema }) {
    try {
        const value = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$secure$2d$json$2d$parse$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].parse(text);
        if (schema == null) {
            return {
                success: true,
                value,
                rawValue: value
            };
        }
        const validationResult = safeValidateTypes({
            value,
            schema
        });
        return validationResult.success ? {
            ...validationResult,
            rawValue: value
        } : validationResult;
    } catch (error) {
        return {
            success: false,
            error: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["JSONParseError"].isInstance(error) ? error : new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["JSONParseError"]({
                text,
                cause: error
            })
        };
    }
}
function isParsableJson(input) {
    try {
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$secure$2d$json$2d$parse$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].parse(input);
        return true;
    } catch (e) {
        return false;
    }
}
;
function parseProviderOptions({ provider, providerOptions, schema }) {
    if ((providerOptions == null ? void 0 : providerOptions[provider]) == null) {
        return void 0;
    }
    const parsedProviderOptions = safeValidateTypes({
        value: providerOptions[provider],
        schema
    });
    if (!parsedProviderOptions.success) {
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InvalidArgumentError"]({
            argument: "providerOptions",
            message: `invalid ${provider} provider options`,
            cause: parsedProviderOptions.error
        });
    }
    return parsedProviderOptions.value;
}
;
var getOriginalFetch2 = ()=>globalThis.fetch;
var postJsonToApi = async ({ url, headers, body, failedResponseHandler, successfulResponseHandler, abortSignal, fetch })=>postToApi({
        url,
        headers: {
            "Content-Type": "application/json",
            ...headers
        },
        body: {
            content: JSON.stringify(body),
            values: body
        },
        failedResponseHandler,
        successfulResponseHandler,
        abortSignal,
        fetch
    });
var postFormDataToApi = async ({ url, headers, formData, failedResponseHandler, successfulResponseHandler, abortSignal, fetch })=>postToApi({
        url,
        headers,
        body: {
            content: formData,
            values: Object.fromEntries(formData.entries())
        },
        failedResponseHandler,
        successfulResponseHandler,
        abortSignal,
        fetch
    });
var postToApi = async ({ url, headers = {}, body, successfulResponseHandler, failedResponseHandler, abortSignal, fetch = getOriginalFetch2() })=>{
    try {
        const response = await fetch(url, {
            method: "POST",
            headers: removeUndefinedEntries(headers),
            body: body.content,
            signal: abortSignal
        });
        const responseHeaders = extractResponseHeaders(response);
        if (!response.ok) {
            let errorInformation;
            try {
                errorInformation = await failedResponseHandler({
                    response,
                    url,
                    requestBodyValues: body.values
                });
            } catch (error) {
                if (isAbortError(error) || __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["APICallError"].isInstance(error)) {
                    throw error;
                }
                throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["APICallError"]({
                    message: "Failed to process error response",
                    cause: error,
                    statusCode: response.status,
                    url,
                    responseHeaders,
                    requestBodyValues: body.values
                });
            }
            throw errorInformation.value;
        }
        try {
            return await successfulResponseHandler({
                response,
                url,
                requestBodyValues: body.values
            });
        } catch (error) {
            if (error instanceof Error) {
                if (isAbortError(error) || __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["APICallError"].isInstance(error)) {
                    throw error;
                }
            }
            throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["APICallError"]({
                message: "Failed to process successful response",
                cause: error,
                statusCode: response.status,
                url,
                responseHeaders,
                requestBodyValues: body.values
            });
        }
    } catch (error) {
        if (isAbortError(error)) {
            throw error;
        }
        if (error instanceof TypeError && error.message === "fetch failed") {
            const cause = error.cause;
            if (cause != null) {
                throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["APICallError"]({
                    message: `Cannot connect to API: ${cause.message}`,
                    cause,
                    url,
                    requestBodyValues: body.values,
                    isRetryable: true
                });
            }
        }
        throw error;
    }
};
// src/resolve.ts
async function resolve(value) {
    if (typeof value === "function") {
        value = value();
    }
    return Promise.resolve(value);
}
;
var createJsonErrorResponseHandler = ({ errorSchema, errorToMessage, isRetryable })=>async ({ response, url, requestBodyValues })=>{
        const responseBody = await response.text();
        const responseHeaders = extractResponseHeaders(response);
        if (responseBody.trim() === "") {
            return {
                responseHeaders,
                value: new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["APICallError"]({
                    message: response.statusText,
                    url,
                    requestBodyValues,
                    statusCode: response.status,
                    responseHeaders,
                    responseBody,
                    isRetryable: isRetryable == null ? void 0 : isRetryable(response)
                })
            };
        }
        try {
            const parsedError = parseJSON({
                text: responseBody,
                schema: errorSchema
            });
            return {
                responseHeaders,
                value: new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["APICallError"]({
                    message: errorToMessage(parsedError),
                    url,
                    requestBodyValues,
                    statusCode: response.status,
                    responseHeaders,
                    responseBody,
                    data: parsedError,
                    isRetryable: isRetryable == null ? void 0 : isRetryable(response, parsedError)
                })
            };
        } catch (parseError) {
            return {
                responseHeaders,
                value: new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["APICallError"]({
                    message: response.statusText,
                    url,
                    requestBodyValues,
                    statusCode: response.status,
                    responseHeaders,
                    responseBody,
                    isRetryable: isRetryable == null ? void 0 : isRetryable(response)
                })
            };
        }
    };
var createEventSourceResponseHandler = (chunkSchema)=>async ({ response })=>{
        const responseHeaders = extractResponseHeaders(response);
        if (response.body == null) {
            throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EmptyResponseBodyError"]({});
        }
        return {
            responseHeaders,
            value: response.body.pipeThrough(new TextDecoderStream()).pipeThrough(createEventSourceParserStream()).pipeThrough(new TransformStream({
                transform ({ data }, controller) {
                    if (data === "[DONE]") {
                        return;
                    }
                    controller.enqueue(safeParseJSON({
                        text: data,
                        schema: chunkSchema
                    }));
                }
            }))
        };
    };
var createJsonStreamResponseHandler = (chunkSchema)=>async ({ response })=>{
        const responseHeaders = extractResponseHeaders(response);
        if (response.body == null) {
            throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EmptyResponseBodyError"]({});
        }
        let buffer = "";
        return {
            responseHeaders,
            value: response.body.pipeThrough(new TextDecoderStream()).pipeThrough(new TransformStream({
                transform (chunkText, controller) {
                    if (chunkText.endsWith("\n")) {
                        controller.enqueue(safeParseJSON({
                            text: buffer + chunkText,
                            schema: chunkSchema
                        }));
                        buffer = "";
                    } else {
                        buffer += chunkText;
                    }
                }
            }))
        };
    };
var createJsonResponseHandler = (responseSchema)=>async ({ response, url, requestBodyValues })=>{
        const responseBody = await response.text();
        const parsedResult = safeParseJSON({
            text: responseBody,
            schema: responseSchema
        });
        const responseHeaders = extractResponseHeaders(response);
        if (!parsedResult.success) {
            throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["APICallError"]({
                message: "Invalid JSON response",
                cause: parsedResult.error,
                statusCode: response.status,
                responseHeaders,
                responseBody,
                url,
                requestBodyValues
            });
        }
        return {
            responseHeaders,
            value: parsedResult.value,
            rawValue: parsedResult.rawValue
        };
    };
var createBinaryResponseHandler = ()=>async ({ response, url, requestBodyValues })=>{
        const responseHeaders = extractResponseHeaders(response);
        if (!response.body) {
            throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["APICallError"]({
                message: "Response body is empty",
                url,
                requestBodyValues,
                statusCode: response.status,
                responseHeaders,
                responseBody: void 0
            });
        }
        try {
            const buffer = await response.arrayBuffer();
            return {
                responseHeaders,
                value: new Uint8Array(buffer)
            };
        } catch (error) {
            throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["APICallError"]({
                message: "Failed to read response as array buffer",
                url,
                requestBodyValues,
                statusCode: response.status,
                responseHeaders,
                responseBody: void 0,
                cause: error
            });
        }
    };
var createStatusCodeErrorResponseHandler = ()=>async ({ response, url, requestBodyValues })=>{
        const responseHeaders = extractResponseHeaders(response);
        const responseBody = await response.text();
        return {
            responseHeaders,
            value: new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["APICallError"]({
                message: response.statusText,
                url,
                requestBodyValues,
                statusCode: response.status,
                responseHeaders,
                responseBody
            })
        };
    };
// src/uint8-utils.ts
var { btoa, atob } = globalThis;
function convertBase64ToUint8Array(base64String) {
    const base64Url = base64String.replace(/-/g, "+").replace(/_/g, "/");
    const latin1string = atob(base64Url);
    return Uint8Array.from(latin1string, (byte)=>byte.codePointAt(0));
}
function convertUint8ArrayToBase64(array) {
    let latin1string = "";
    for(let i = 0; i < array.length; i++){
        latin1string += String.fromCodePoint(array[i]);
    }
    return btoa(latin1string);
}
// src/without-trailing-slash.ts
function withoutTrailingSlash(url) {
    return url == null ? void 0 : url.replace(/\/$/, "");
}
;
 //# sourceMappingURL=index.mjs.map
}}),
"[project]/node_modules/@ai-sdk/ui-utils/dist/index.mjs [app-client] (ecmascript) <locals>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
// src/index.ts
__turbopack_context__.s({
    "asSchema": (()=>asSchema),
    "callChatApi": (()=>callChatApi),
    "callCompletionApi": (()=>callCompletionApi),
    "extractMaxToolInvocationStep": (()=>extractMaxToolInvocationStep),
    "fillMessageParts": (()=>fillMessageParts),
    "formatAssistantStreamPart": (()=>formatAssistantStreamPart),
    "formatDataStreamPart": (()=>formatDataStreamPart),
    "getMessageParts": (()=>getMessageParts),
    "getTextFromDataUrl": (()=>getTextFromDataUrl),
    "isAssistantMessageWithCompletedToolCalls": (()=>isAssistantMessageWithCompletedToolCalls),
    "isDeepEqualData": (()=>isDeepEqualData),
    "jsonSchema": (()=>jsonSchema),
    "parseAssistantStreamPart": (()=>parseAssistantStreamPart),
    "parseDataStreamPart": (()=>parseDataStreamPart),
    "parsePartialJson": (()=>parsePartialJson),
    "prepareAttachmentsForRequest": (()=>prepareAttachmentsForRequest),
    "processAssistantStream": (()=>processAssistantStream),
    "processDataStream": (()=>processDataStream),
    "processTextStream": (()=>processTextStream),
    "shouldResubmitMessages": (()=>shouldResubmitMessages),
    "updateToolCallResult": (()=>updateToolCallResult),
    "zodSchema": (()=>zodSchema)
});
// src/process-chat-response.ts
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@ai-sdk/provider-utils/dist/index.mjs [app-client] (ecmascript)");
// src/zod-schema.ts
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2d$to$2d$json$2d$schema$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/zod-to-json-schema/dist/esm/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2d$to$2d$json$2d$schema$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/zod-to-json-schema/dist/esm/index.js [app-client] (ecmascript) <locals>");
;
// src/assistant-stream-parts.ts
var textStreamPart = {
    code: "0",
    name: "text",
    parse: (value)=>{
        if (typeof value !== "string") {
            throw new Error('"text" parts expect a string value.');
        }
        return {
            type: "text",
            value
        };
    }
};
var errorStreamPart = {
    code: "3",
    name: "error",
    parse: (value)=>{
        if (typeof value !== "string") {
            throw new Error('"error" parts expect a string value.');
        }
        return {
            type: "error",
            value
        };
    }
};
var assistantMessageStreamPart = {
    code: "4",
    name: "assistant_message",
    parse: (value)=>{
        if (value == null || typeof value !== "object" || !("id" in value) || !("role" in value) || !("content" in value) || typeof value.id !== "string" || typeof value.role !== "string" || value.role !== "assistant" || !Array.isArray(value.content) || !value.content.every((item)=>item != null && typeof item === "object" && "type" in item && item.type === "text" && "text" in item && item.text != null && typeof item.text === "object" && "value" in item.text && typeof item.text.value === "string")) {
            throw new Error('"assistant_message" parts expect an object with an "id", "role", and "content" property.');
        }
        return {
            type: "assistant_message",
            value
        };
    }
};
var assistantControlDataStreamPart = {
    code: "5",
    name: "assistant_control_data",
    parse: (value)=>{
        if (value == null || typeof value !== "object" || !("threadId" in value) || !("messageId" in value) || typeof value.threadId !== "string" || typeof value.messageId !== "string") {
            throw new Error('"assistant_control_data" parts expect an object with a "threadId" and "messageId" property.');
        }
        return {
            type: "assistant_control_data",
            value: {
                threadId: value.threadId,
                messageId: value.messageId
            }
        };
    }
};
var dataMessageStreamPart = {
    code: "6",
    name: "data_message",
    parse: (value)=>{
        if (value == null || typeof value !== "object" || !("role" in value) || !("data" in value) || typeof value.role !== "string" || value.role !== "data") {
            throw new Error('"data_message" parts expect an object with a "role" and "data" property.');
        }
        return {
            type: "data_message",
            value
        };
    }
};
var assistantStreamParts = [
    textStreamPart,
    errorStreamPart,
    assistantMessageStreamPart,
    assistantControlDataStreamPart,
    dataMessageStreamPart
];
var assistantStreamPartsByCode = {
    [textStreamPart.code]: textStreamPart,
    [errorStreamPart.code]: errorStreamPart,
    [assistantMessageStreamPart.code]: assistantMessageStreamPart,
    [assistantControlDataStreamPart.code]: assistantControlDataStreamPart,
    [dataMessageStreamPart.code]: dataMessageStreamPart
};
var StreamStringPrefixes = {
    [textStreamPart.name]: textStreamPart.code,
    [errorStreamPart.name]: errorStreamPart.code,
    [assistantMessageStreamPart.name]: assistantMessageStreamPart.code,
    [assistantControlDataStreamPart.name]: assistantControlDataStreamPart.code,
    [dataMessageStreamPart.name]: dataMessageStreamPart.code
};
var validCodes = assistantStreamParts.map((part)=>part.code);
var parseAssistantStreamPart = (line)=>{
    const firstSeparatorIndex = line.indexOf(":");
    if (firstSeparatorIndex === -1) {
        throw new Error("Failed to parse stream string. No separator found.");
    }
    const prefix = line.slice(0, firstSeparatorIndex);
    if (!validCodes.includes(prefix)) {
        throw new Error(`Failed to parse stream string. Invalid code ${prefix}.`);
    }
    const code = prefix;
    const textValue = line.slice(firstSeparatorIndex + 1);
    const jsonValue = JSON.parse(textValue);
    return assistantStreamPartsByCode[code].parse(jsonValue);
};
function formatAssistantStreamPart(type, value) {
    const streamPart = assistantStreamParts.find((part)=>part.name === type);
    if (!streamPart) {
        throw new Error(`Invalid stream part type: ${type}`);
    }
    return `${streamPart.code}:${JSON.stringify(value)}
`;
}
;
// src/duplicated/usage.ts
function calculateLanguageModelUsage({ promptTokens, completionTokens }) {
    return {
        promptTokens,
        completionTokens,
        totalTokens: promptTokens + completionTokens
    };
}
;
// src/fix-json.ts
function fixJson(input) {
    const stack = [
        "ROOT"
    ];
    let lastValidIndex = -1;
    let literalStart = null;
    function processValueStart(char, i, swapState) {
        {
            switch(char){
                case '"':
                    {
                        lastValidIndex = i;
                        stack.pop();
                        stack.push(swapState);
                        stack.push("INSIDE_STRING");
                        break;
                    }
                case "f":
                case "t":
                case "n":
                    {
                        lastValidIndex = i;
                        literalStart = i;
                        stack.pop();
                        stack.push(swapState);
                        stack.push("INSIDE_LITERAL");
                        break;
                    }
                case "-":
                    {
                        stack.pop();
                        stack.push(swapState);
                        stack.push("INSIDE_NUMBER");
                        break;
                    }
                case "0":
                case "1":
                case "2":
                case "3":
                case "4":
                case "5":
                case "6":
                case "7":
                case "8":
                case "9":
                    {
                        lastValidIndex = i;
                        stack.pop();
                        stack.push(swapState);
                        stack.push("INSIDE_NUMBER");
                        break;
                    }
                case "{":
                    {
                        lastValidIndex = i;
                        stack.pop();
                        stack.push(swapState);
                        stack.push("INSIDE_OBJECT_START");
                        break;
                    }
                case "[":
                    {
                        lastValidIndex = i;
                        stack.pop();
                        stack.push(swapState);
                        stack.push("INSIDE_ARRAY_START");
                        break;
                    }
            }
        }
    }
    function processAfterObjectValue(char, i) {
        switch(char){
            case ",":
                {
                    stack.pop();
                    stack.push("INSIDE_OBJECT_AFTER_COMMA");
                    break;
                }
            case "}":
                {
                    lastValidIndex = i;
                    stack.pop();
                    break;
                }
        }
    }
    function processAfterArrayValue(char, i) {
        switch(char){
            case ",":
                {
                    stack.pop();
                    stack.push("INSIDE_ARRAY_AFTER_COMMA");
                    break;
                }
            case "]":
                {
                    lastValidIndex = i;
                    stack.pop();
                    break;
                }
        }
    }
    for(let i = 0; i < input.length; i++){
        const char = input[i];
        const currentState = stack[stack.length - 1];
        switch(currentState){
            case "ROOT":
                processValueStart(char, i, "FINISH");
                break;
            case "INSIDE_OBJECT_START":
                {
                    switch(char){
                        case '"':
                            {
                                stack.pop();
                                stack.push("INSIDE_OBJECT_KEY");
                                break;
                            }
                        case "}":
                            {
                                lastValidIndex = i;
                                stack.pop();
                                break;
                            }
                    }
                    break;
                }
            case "INSIDE_OBJECT_AFTER_COMMA":
                {
                    switch(char){
                        case '"':
                            {
                                stack.pop();
                                stack.push("INSIDE_OBJECT_KEY");
                                break;
                            }
                    }
                    break;
                }
            case "INSIDE_OBJECT_KEY":
                {
                    switch(char){
                        case '"':
                            {
                                stack.pop();
                                stack.push("INSIDE_OBJECT_AFTER_KEY");
                                break;
                            }
                    }
                    break;
                }
            case "INSIDE_OBJECT_AFTER_KEY":
                {
                    switch(char){
                        case ":":
                            {
                                stack.pop();
                                stack.push("INSIDE_OBJECT_BEFORE_VALUE");
                                break;
                            }
                    }
                    break;
                }
            case "INSIDE_OBJECT_BEFORE_VALUE":
                {
                    processValueStart(char, i, "INSIDE_OBJECT_AFTER_VALUE");
                    break;
                }
            case "INSIDE_OBJECT_AFTER_VALUE":
                {
                    processAfterObjectValue(char, i);
                    break;
                }
            case "INSIDE_STRING":
                {
                    switch(char){
                        case '"':
                            {
                                stack.pop();
                                lastValidIndex = i;
                                break;
                            }
                        case "\\":
                            {
                                stack.push("INSIDE_STRING_ESCAPE");
                                break;
                            }
                        default:
                            {
                                lastValidIndex = i;
                            }
                    }
                    break;
                }
            case "INSIDE_ARRAY_START":
                {
                    switch(char){
                        case "]":
                            {
                                lastValidIndex = i;
                                stack.pop();
                                break;
                            }
                        default:
                            {
                                lastValidIndex = i;
                                processValueStart(char, i, "INSIDE_ARRAY_AFTER_VALUE");
                                break;
                            }
                    }
                    break;
                }
            case "INSIDE_ARRAY_AFTER_VALUE":
                {
                    switch(char){
                        case ",":
                            {
                                stack.pop();
                                stack.push("INSIDE_ARRAY_AFTER_COMMA");
                                break;
                            }
                        case "]":
                            {
                                lastValidIndex = i;
                                stack.pop();
                                break;
                            }
                        default:
                            {
                                lastValidIndex = i;
                                break;
                            }
                    }
                    break;
                }
            case "INSIDE_ARRAY_AFTER_COMMA":
                {
                    processValueStart(char, i, "INSIDE_ARRAY_AFTER_VALUE");
                    break;
                }
            case "INSIDE_STRING_ESCAPE":
                {
                    stack.pop();
                    lastValidIndex = i;
                    break;
                }
            case "INSIDE_NUMBER":
                {
                    switch(char){
                        case "0":
                        case "1":
                        case "2":
                        case "3":
                        case "4":
                        case "5":
                        case "6":
                        case "7":
                        case "8":
                        case "9":
                            {
                                lastValidIndex = i;
                                break;
                            }
                        case "e":
                        case "E":
                        case "-":
                        case ".":
                            {
                                break;
                            }
                        case ",":
                            {
                                stack.pop();
                                if (stack[stack.length - 1] === "INSIDE_ARRAY_AFTER_VALUE") {
                                    processAfterArrayValue(char, i);
                                }
                                if (stack[stack.length - 1] === "INSIDE_OBJECT_AFTER_VALUE") {
                                    processAfterObjectValue(char, i);
                                }
                                break;
                            }
                        case "}":
                            {
                                stack.pop();
                                if (stack[stack.length - 1] === "INSIDE_OBJECT_AFTER_VALUE") {
                                    processAfterObjectValue(char, i);
                                }
                                break;
                            }
                        case "]":
                            {
                                stack.pop();
                                if (stack[stack.length - 1] === "INSIDE_ARRAY_AFTER_VALUE") {
                                    processAfterArrayValue(char, i);
                                }
                                break;
                            }
                        default:
                            {
                                stack.pop();
                                break;
                            }
                    }
                    break;
                }
            case "INSIDE_LITERAL":
                {
                    const partialLiteral = input.substring(literalStart, i + 1);
                    if (!"false".startsWith(partialLiteral) && !"true".startsWith(partialLiteral) && !"null".startsWith(partialLiteral)) {
                        stack.pop();
                        if (stack[stack.length - 1] === "INSIDE_OBJECT_AFTER_VALUE") {
                            processAfterObjectValue(char, i);
                        } else if (stack[stack.length - 1] === "INSIDE_ARRAY_AFTER_VALUE") {
                            processAfterArrayValue(char, i);
                        }
                    } else {
                        lastValidIndex = i;
                    }
                    break;
                }
        }
    }
    let result = input.slice(0, lastValidIndex + 1);
    for(let i = stack.length - 1; i >= 0; i--){
        const state = stack[i];
        switch(state){
            case "INSIDE_STRING":
                {
                    result += '"';
                    break;
                }
            case "INSIDE_OBJECT_KEY":
            case "INSIDE_OBJECT_AFTER_KEY":
            case "INSIDE_OBJECT_AFTER_COMMA":
            case "INSIDE_OBJECT_START":
            case "INSIDE_OBJECT_BEFORE_VALUE":
            case "INSIDE_OBJECT_AFTER_VALUE":
                {
                    result += "}";
                    break;
                }
            case "INSIDE_ARRAY_START":
            case "INSIDE_ARRAY_AFTER_COMMA":
            case "INSIDE_ARRAY_AFTER_VALUE":
                {
                    result += "]";
                    break;
                }
            case "INSIDE_LITERAL":
                {
                    const partialLiteral = input.substring(literalStart, input.length);
                    if ("true".startsWith(partialLiteral)) {
                        result += "true".slice(partialLiteral.length);
                    } else if ("false".startsWith(partialLiteral)) {
                        result += "false".slice(partialLiteral.length);
                    } else if ("null".startsWith(partialLiteral)) {
                        result += "null".slice(partialLiteral.length);
                    }
                }
        }
    }
    return result;
}
// src/parse-partial-json.ts
function parsePartialJson(jsonText) {
    if (jsonText === void 0) {
        return {
            value: void 0,
            state: "undefined-input"
        };
    }
    let result = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["safeParseJSON"])({
        text: jsonText
    });
    if (result.success) {
        return {
            value: result.value,
            state: "successful-parse"
        };
    }
    result = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["safeParseJSON"])({
        text: fixJson(jsonText)
    });
    if (result.success) {
        return {
            value: result.value,
            state: "repaired-parse"
        };
    }
    return {
        value: void 0,
        state: "failed-parse"
    };
}
// src/data-stream-parts.ts
var textStreamPart2 = {
    code: "0",
    name: "text",
    parse: (value)=>{
        if (typeof value !== "string") {
            throw new Error('"text" parts expect a string value.');
        }
        return {
            type: "text",
            value
        };
    }
};
var dataStreamPart = {
    code: "2",
    name: "data",
    parse: (value)=>{
        if (!Array.isArray(value)) {
            throw new Error('"data" parts expect an array value.');
        }
        return {
            type: "data",
            value
        };
    }
};
var errorStreamPart2 = {
    code: "3",
    name: "error",
    parse: (value)=>{
        if (typeof value !== "string") {
            throw new Error('"error" parts expect a string value.');
        }
        return {
            type: "error",
            value
        };
    }
};
var messageAnnotationsStreamPart = {
    code: "8",
    name: "message_annotations",
    parse: (value)=>{
        if (!Array.isArray(value)) {
            throw new Error('"message_annotations" parts expect an array value.');
        }
        return {
            type: "message_annotations",
            value
        };
    }
};
var toolCallStreamPart = {
    code: "9",
    name: "tool_call",
    parse: (value)=>{
        if (value == null || typeof value !== "object" || !("toolCallId" in value) || typeof value.toolCallId !== "string" || !("toolName" in value) || typeof value.toolName !== "string" || !("args" in value) || typeof value.args !== "object") {
            throw new Error('"tool_call" parts expect an object with a "toolCallId", "toolName", and "args" property.');
        }
        return {
            type: "tool_call",
            value
        };
    }
};
var toolResultStreamPart = {
    code: "a",
    name: "tool_result",
    parse: (value)=>{
        if (value == null || typeof value !== "object" || !("toolCallId" in value) || typeof value.toolCallId !== "string" || !("result" in value)) {
            throw new Error('"tool_result" parts expect an object with a "toolCallId" and a "result" property.');
        }
        return {
            type: "tool_result",
            value
        };
    }
};
var toolCallStreamingStartStreamPart = {
    code: "b",
    name: "tool_call_streaming_start",
    parse: (value)=>{
        if (value == null || typeof value !== "object" || !("toolCallId" in value) || typeof value.toolCallId !== "string" || !("toolName" in value) || typeof value.toolName !== "string") {
            throw new Error('"tool_call_streaming_start" parts expect an object with a "toolCallId" and "toolName" property.');
        }
        return {
            type: "tool_call_streaming_start",
            value
        };
    }
};
var toolCallDeltaStreamPart = {
    code: "c",
    name: "tool_call_delta",
    parse: (value)=>{
        if (value == null || typeof value !== "object" || !("toolCallId" in value) || typeof value.toolCallId !== "string" || !("argsTextDelta" in value) || typeof value.argsTextDelta !== "string") {
            throw new Error('"tool_call_delta" parts expect an object with a "toolCallId" and "argsTextDelta" property.');
        }
        return {
            type: "tool_call_delta",
            value
        };
    }
};
var finishMessageStreamPart = {
    code: "d",
    name: "finish_message",
    parse: (value)=>{
        if (value == null || typeof value !== "object" || !("finishReason" in value) || typeof value.finishReason !== "string") {
            throw new Error('"finish_message" parts expect an object with a "finishReason" property.');
        }
        const result = {
            finishReason: value.finishReason
        };
        if ("usage" in value && value.usage != null && typeof value.usage === "object" && "promptTokens" in value.usage && "completionTokens" in value.usage) {
            result.usage = {
                promptTokens: typeof value.usage.promptTokens === "number" ? value.usage.promptTokens : Number.NaN,
                completionTokens: typeof value.usage.completionTokens === "number" ? value.usage.completionTokens : Number.NaN
            };
        }
        return {
            type: "finish_message",
            value: result
        };
    }
};
var finishStepStreamPart = {
    code: "e",
    name: "finish_step",
    parse: (value)=>{
        if (value == null || typeof value !== "object" || !("finishReason" in value) || typeof value.finishReason !== "string") {
            throw new Error('"finish_step" parts expect an object with a "finishReason" property.');
        }
        const result = {
            finishReason: value.finishReason,
            isContinued: false
        };
        if ("usage" in value && value.usage != null && typeof value.usage === "object" && "promptTokens" in value.usage && "completionTokens" in value.usage) {
            result.usage = {
                promptTokens: typeof value.usage.promptTokens === "number" ? value.usage.promptTokens : Number.NaN,
                completionTokens: typeof value.usage.completionTokens === "number" ? value.usage.completionTokens : Number.NaN
            };
        }
        if ("isContinued" in value && typeof value.isContinued === "boolean") {
            result.isContinued = value.isContinued;
        }
        return {
            type: "finish_step",
            value: result
        };
    }
};
var startStepStreamPart = {
    code: "f",
    name: "start_step",
    parse: (value)=>{
        if (value == null || typeof value !== "object" || !("messageId" in value) || typeof value.messageId !== "string") {
            throw new Error('"start_step" parts expect an object with an "id" property.');
        }
        return {
            type: "start_step",
            value: {
                messageId: value.messageId
            }
        };
    }
};
var reasoningStreamPart = {
    code: "g",
    name: "reasoning",
    parse: (value)=>{
        if (typeof value !== "string") {
            throw new Error('"reasoning" parts expect a string value.');
        }
        return {
            type: "reasoning",
            value
        };
    }
};
var sourcePart = {
    code: "h",
    name: "source",
    parse: (value)=>{
        if (value == null || typeof value !== "object") {
            throw new Error('"source" parts expect a Source object.');
        }
        return {
            type: "source",
            value
        };
    }
};
var redactedReasoningStreamPart = {
    code: "i",
    name: "redacted_reasoning",
    parse: (value)=>{
        if (value == null || typeof value !== "object" || !("data" in value) || typeof value.data !== "string") {
            throw new Error('"redacted_reasoning" parts expect an object with a "data" property.');
        }
        return {
            type: "redacted_reasoning",
            value: {
                data: value.data
            }
        };
    }
};
var reasoningSignatureStreamPart = {
    code: "j",
    name: "reasoning_signature",
    parse: (value)=>{
        if (value == null || typeof value !== "object" || !("signature" in value) || typeof value.signature !== "string") {
            throw new Error('"reasoning_signature" parts expect an object with a "signature" property.');
        }
        return {
            type: "reasoning_signature",
            value: {
                signature: value.signature
            }
        };
    }
};
var fileStreamPart = {
    code: "k",
    name: "file",
    parse: (value)=>{
        if (value == null || typeof value !== "object" || !("data" in value) || typeof value.data !== "string" || !("mimeType" in value) || typeof value.mimeType !== "string") {
            throw new Error('"file" parts expect an object with a "data" and "mimeType" property.');
        }
        return {
            type: "file",
            value
        };
    }
};
var dataStreamParts = [
    textStreamPart2,
    dataStreamPart,
    errorStreamPart2,
    messageAnnotationsStreamPart,
    toolCallStreamPart,
    toolResultStreamPart,
    toolCallStreamingStartStreamPart,
    toolCallDeltaStreamPart,
    finishMessageStreamPart,
    finishStepStreamPart,
    startStepStreamPart,
    reasoningStreamPart,
    sourcePart,
    redactedReasoningStreamPart,
    reasoningSignatureStreamPart,
    fileStreamPart
];
var dataStreamPartsByCode = Object.fromEntries(dataStreamParts.map((part)=>[
        part.code,
        part
    ]));
var DataStreamStringPrefixes = Object.fromEntries(dataStreamParts.map((part)=>[
        part.name,
        part.code
    ]));
var validCodes2 = dataStreamParts.map((part)=>part.code);
var parseDataStreamPart = (line)=>{
    const firstSeparatorIndex = line.indexOf(":");
    if (firstSeparatorIndex === -1) {
        throw new Error("Failed to parse stream string. No separator found.");
    }
    const prefix = line.slice(0, firstSeparatorIndex);
    if (!validCodes2.includes(prefix)) {
        throw new Error(`Failed to parse stream string. Invalid code ${prefix}.`);
    }
    const code = prefix;
    const textValue = line.slice(firstSeparatorIndex + 1);
    const jsonValue = JSON.parse(textValue);
    return dataStreamPartsByCode[code].parse(jsonValue);
};
function formatDataStreamPart(type, value) {
    const streamPart = dataStreamParts.find((part)=>part.name === type);
    if (!streamPart) {
        throw new Error(`Invalid stream part type: ${type}`);
    }
    return `${streamPart.code}:${JSON.stringify(value)}
`;
}
// src/process-data-stream.ts
var NEWLINE = "\n".charCodeAt(0);
function concatChunks(chunks, totalLength) {
    const concatenatedChunks = new Uint8Array(totalLength);
    let offset = 0;
    for (const chunk of chunks){
        concatenatedChunks.set(chunk, offset);
        offset += chunk.length;
    }
    chunks.length = 0;
    return concatenatedChunks;
}
async function processDataStream({ stream, onTextPart, onReasoningPart, onReasoningSignaturePart, onRedactedReasoningPart, onSourcePart, onFilePart, onDataPart, onErrorPart, onToolCallStreamingStartPart, onToolCallDeltaPart, onToolCallPart, onToolResultPart, onMessageAnnotationsPart, onFinishMessagePart, onFinishStepPart, onStartStepPart }) {
    const reader = stream.getReader();
    const decoder = new TextDecoder();
    const chunks = [];
    let totalLength = 0;
    while(true){
        const { value } = await reader.read();
        if (value) {
            chunks.push(value);
            totalLength += value.length;
            if (value[value.length - 1] !== NEWLINE) {
                continue;
            }
        }
        if (chunks.length === 0) {
            break;
        }
        const concatenatedChunks = concatChunks(chunks, totalLength);
        totalLength = 0;
        const streamParts = decoder.decode(concatenatedChunks, {
            stream: true
        }).split("\n").filter((line)=>line !== "").map(parseDataStreamPart);
        for (const { type, value: value2 } of streamParts){
            switch(type){
                case "text":
                    await (onTextPart == null ? void 0 : onTextPart(value2));
                    break;
                case "reasoning":
                    await (onReasoningPart == null ? void 0 : onReasoningPart(value2));
                    break;
                case "reasoning_signature":
                    await (onReasoningSignaturePart == null ? void 0 : onReasoningSignaturePart(value2));
                    break;
                case "redacted_reasoning":
                    await (onRedactedReasoningPart == null ? void 0 : onRedactedReasoningPart(value2));
                    break;
                case "file":
                    await (onFilePart == null ? void 0 : onFilePart(value2));
                    break;
                case "source":
                    await (onSourcePart == null ? void 0 : onSourcePart(value2));
                    break;
                case "data":
                    await (onDataPart == null ? void 0 : onDataPart(value2));
                    break;
                case "error":
                    await (onErrorPart == null ? void 0 : onErrorPart(value2));
                    break;
                case "message_annotations":
                    await (onMessageAnnotationsPart == null ? void 0 : onMessageAnnotationsPart(value2));
                    break;
                case "tool_call_streaming_start":
                    await (onToolCallStreamingStartPart == null ? void 0 : onToolCallStreamingStartPart(value2));
                    break;
                case "tool_call_delta":
                    await (onToolCallDeltaPart == null ? void 0 : onToolCallDeltaPart(value2));
                    break;
                case "tool_call":
                    await (onToolCallPart == null ? void 0 : onToolCallPart(value2));
                    break;
                case "tool_result":
                    await (onToolResultPart == null ? void 0 : onToolResultPart(value2));
                    break;
                case "finish_message":
                    await (onFinishMessagePart == null ? void 0 : onFinishMessagePart(value2));
                    break;
                case "finish_step":
                    await (onFinishStepPart == null ? void 0 : onFinishStepPart(value2));
                    break;
                case "start_step":
                    await (onStartStepPart == null ? void 0 : onStartStepPart(value2));
                    break;
                default:
                    {
                        const exhaustiveCheck = type;
                        throw new Error(`Unknown stream part type: ${exhaustiveCheck}`);
                    }
            }
        }
    }
}
// src/process-chat-response.ts
async function processChatResponse({ stream, update, onToolCall, onFinish, generateId: generateId2 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["generateId"], getCurrentDate = ()=>/* @__PURE__ */ new Date(), lastMessage }) {
    var _a, _b;
    const replaceLastMessage = (lastMessage == null ? void 0 : lastMessage.role) === "assistant";
    let step = replaceLastMessage ? 1 + // find max step in existing tool invocations:
    ((_b = (_a = lastMessage.toolInvocations) == null ? void 0 : _a.reduce((max, toolInvocation)=>{
        var _a2;
        return Math.max(max, (_a2 = toolInvocation.step) != null ? _a2 : 0);
    }, 0)) != null ? _b : 0) : 0;
    const message = replaceLastMessage ? structuredClone(lastMessage) : {
        id: generateId2(),
        createdAt: getCurrentDate(),
        role: "assistant",
        content: "",
        parts: []
    };
    let currentTextPart = void 0;
    let currentReasoningPart = void 0;
    let currentReasoningTextDetail = void 0;
    function updateToolInvocationPart(toolCallId, invocation) {
        const part = message.parts.find((part2)=>part2.type === "tool-invocation" && part2.toolInvocation.toolCallId === toolCallId);
        if (part != null) {
            part.toolInvocation = invocation;
        } else {
            message.parts.push({
                type: "tool-invocation",
                toolInvocation: invocation
            });
        }
    }
    const data = [];
    let messageAnnotations = replaceLastMessage ? lastMessage == null ? void 0 : lastMessage.annotations : void 0;
    const partialToolCalls = {};
    let usage = {
        completionTokens: NaN,
        promptTokens: NaN,
        totalTokens: NaN
    };
    let finishReason = "unknown";
    function execUpdate() {
        const copiedData = [
            ...data
        ];
        if (messageAnnotations == null ? void 0 : messageAnnotations.length) {
            message.annotations = messageAnnotations;
        }
        const copiedMessage = {
            // deep copy the message to ensure that deep changes (msg attachments) are updated
            // with SolidJS. SolidJS uses referential integration of sub-objects to detect changes.
            ...structuredClone(message),
            // add a revision id to ensure that the message is updated with SWR. SWR uses a
            // hashing approach by default to detect changes, but it only works for shallow
            // changes. This is why we need to add a revision id to ensure that the message
            // is updated with SWR (without it, the changes get stuck in SWR and are not
            // forwarded to rendering):
            revisionId: generateId2()
        };
        update({
            message: copiedMessage,
            data: copiedData,
            replaceLastMessage
        });
    }
    await processDataStream({
        stream,
        onTextPart (value) {
            if (currentTextPart == null) {
                currentTextPart = {
                    type: "text",
                    text: value
                };
                message.parts.push(currentTextPart);
            } else {
                currentTextPart.text += value;
            }
            message.content += value;
            execUpdate();
        },
        onReasoningPart (value) {
            var _a2;
            if (currentReasoningTextDetail == null) {
                currentReasoningTextDetail = {
                    type: "text",
                    text: value
                };
                if (currentReasoningPart != null) {
                    currentReasoningPart.details.push(currentReasoningTextDetail);
                }
            } else {
                currentReasoningTextDetail.text += value;
            }
            if (currentReasoningPart == null) {
                currentReasoningPart = {
                    type: "reasoning",
                    reasoning: value,
                    details: [
                        currentReasoningTextDetail
                    ]
                };
                message.parts.push(currentReasoningPart);
            } else {
                currentReasoningPart.reasoning += value;
            }
            message.reasoning = ((_a2 = message.reasoning) != null ? _a2 : "") + value;
            execUpdate();
        },
        onReasoningSignaturePart (value) {
            if (currentReasoningTextDetail != null) {
                currentReasoningTextDetail.signature = value.signature;
            }
        },
        onRedactedReasoningPart (value) {
            if (currentReasoningPart == null) {
                currentReasoningPart = {
                    type: "reasoning",
                    reasoning: "",
                    details: []
                };
                message.parts.push(currentReasoningPart);
            }
            currentReasoningPart.details.push({
                type: "redacted",
                data: value.data
            });
            currentReasoningTextDetail = void 0;
            execUpdate();
        },
        onFilePart (value) {
            message.parts.push({
                type: "file",
                mimeType: value.mimeType,
                data: value.data
            });
            execUpdate();
        },
        onSourcePart (value) {
            message.parts.push({
                type: "source",
                source: value
            });
            execUpdate();
        },
        onToolCallStreamingStartPart (value) {
            if (message.toolInvocations == null) {
                message.toolInvocations = [];
            }
            partialToolCalls[value.toolCallId] = {
                text: "",
                step,
                toolName: value.toolName,
                index: message.toolInvocations.length
            };
            const invocation = {
                state: "partial-call",
                step,
                toolCallId: value.toolCallId,
                toolName: value.toolName,
                args: void 0
            };
            message.toolInvocations.push(invocation);
            updateToolInvocationPart(value.toolCallId, invocation);
            execUpdate();
        },
        onToolCallDeltaPart (value) {
            const partialToolCall = partialToolCalls[value.toolCallId];
            partialToolCall.text += value.argsTextDelta;
            const { value: partialArgs } = parsePartialJson(partialToolCall.text);
            const invocation = {
                state: "partial-call",
                step: partialToolCall.step,
                toolCallId: value.toolCallId,
                toolName: partialToolCall.toolName,
                args: partialArgs
            };
            message.toolInvocations[partialToolCall.index] = invocation;
            updateToolInvocationPart(value.toolCallId, invocation);
            execUpdate();
        },
        async onToolCallPart (value) {
            const invocation = {
                state: "call",
                step,
                ...value
            };
            if (partialToolCalls[value.toolCallId] != null) {
                message.toolInvocations[partialToolCalls[value.toolCallId].index] = invocation;
            } else {
                if (message.toolInvocations == null) {
                    message.toolInvocations = [];
                }
                message.toolInvocations.push(invocation);
            }
            updateToolInvocationPart(value.toolCallId, invocation);
            execUpdate();
            if (onToolCall) {
                const result = await onToolCall({
                    toolCall: value
                });
                if (result != null) {
                    const invocation2 = {
                        state: "result",
                        step,
                        ...value,
                        result
                    };
                    message.toolInvocations[message.toolInvocations.length - 1] = invocation2;
                    updateToolInvocationPart(value.toolCallId, invocation2);
                    execUpdate();
                }
            }
        },
        onToolResultPart (value) {
            const toolInvocations = message.toolInvocations;
            if (toolInvocations == null) {
                throw new Error("tool_result must be preceded by a tool_call");
            }
            const toolInvocationIndex = toolInvocations.findIndex((invocation2)=>invocation2.toolCallId === value.toolCallId);
            if (toolInvocationIndex === -1) {
                throw new Error("tool_result must be preceded by a tool_call with the same toolCallId");
            }
            const invocation = {
                ...toolInvocations[toolInvocationIndex],
                state: "result",
                ...value
            };
            toolInvocations[toolInvocationIndex] = invocation;
            updateToolInvocationPart(value.toolCallId, invocation);
            execUpdate();
        },
        onDataPart (value) {
            data.push(...value);
            execUpdate();
        },
        onMessageAnnotationsPart (value) {
            if (messageAnnotations == null) {
                messageAnnotations = [
                    ...value
                ];
            } else {
                messageAnnotations.push(...value);
            }
            execUpdate();
        },
        onFinishStepPart (value) {
            step += 1;
            currentTextPart = value.isContinued ? currentTextPart : void 0;
            currentReasoningPart = void 0;
            currentReasoningTextDetail = void 0;
        },
        onStartStepPart (value) {
            if (!replaceLastMessage) {
                message.id = value.messageId;
            }
            message.parts.push({
                type: "step-start"
            });
            execUpdate();
        },
        onFinishMessagePart (value) {
            finishReason = value.finishReason;
            if (value.usage != null) {
                usage = calculateLanguageModelUsage(value.usage);
            }
        },
        onErrorPart (error) {
            throw new Error(error);
        }
    });
    onFinish == null ? void 0 : onFinish({
        message,
        finishReason,
        usage
    });
}
;
// src/process-text-stream.ts
async function processTextStream({ stream, onTextPart }) {
    const reader = stream.pipeThrough(new TextDecoderStream()).getReader();
    while(true){
        const { done, value } = await reader.read();
        if (done) {
            break;
        }
        await onTextPart(value);
    }
}
// src/process-chat-text-response.ts
async function processChatTextResponse({ stream, update, onFinish, getCurrentDate = ()=>/* @__PURE__ */ new Date(), generateId: generateId2 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["generateId"] }) {
    const textPart = {
        type: "text",
        text: ""
    };
    const resultMessage = {
        id: generateId2(),
        createdAt: getCurrentDate(),
        role: "assistant",
        content: "",
        parts: [
            textPart
        ]
    };
    await processTextStream({
        stream,
        onTextPart: (chunk)=>{
            resultMessage.content += chunk;
            textPart.text += chunk;
            update({
                message: {
                    ...resultMessage
                },
                data: [],
                replaceLastMessage: false
            });
        }
    });
    onFinish == null ? void 0 : onFinish(resultMessage, {
        usage: {
            completionTokens: NaN,
            promptTokens: NaN,
            totalTokens: NaN
        },
        finishReason: "unknown"
    });
}
// src/call-chat-api.ts
var getOriginalFetch = ()=>fetch;
async function callChatApi({ api, body, streamProtocol = "data", credentials, headers, abortController, restoreMessagesOnFailure, onResponse, onUpdate, onFinish, onToolCall, generateId: generateId2, fetch: fetch2 = getOriginalFetch(), lastMessage, requestType = "generate" }) {
    var _a, _b, _c;
    const request = requestType === "resume" ? fetch2(`${api}?chatId=${body.id}`, {
        method: "GET",
        headers: {
            "Content-Type": "application/json",
            ...headers
        },
        signal: (_a = abortController == null ? void 0 : abortController()) == null ? void 0 : _a.signal,
        credentials
    }) : fetch2(api, {
        method: "POST",
        body: JSON.stringify(body),
        headers: {
            "Content-Type": "application/json",
            ...headers
        },
        signal: (_b = abortController == null ? void 0 : abortController()) == null ? void 0 : _b.signal,
        credentials
    });
    const response = await request.catch((err)=>{
        restoreMessagesOnFailure();
        throw err;
    });
    if (onResponse) {
        try {
            await onResponse(response);
        } catch (err) {
            throw err;
        }
    }
    if (!response.ok) {
        restoreMessagesOnFailure();
        throw new Error((_c = await response.text()) != null ? _c : "Failed to fetch the chat response.");
    }
    if (!response.body) {
        throw new Error("The response body is empty.");
    }
    switch(streamProtocol){
        case "text":
            {
                await processChatTextResponse({
                    stream: response.body,
                    update: onUpdate,
                    onFinish,
                    generateId: generateId2
                });
                return;
            }
        case "data":
            {
                await processChatResponse({
                    stream: response.body,
                    update: onUpdate,
                    lastMessage,
                    onToolCall,
                    onFinish ({ message, finishReason, usage }) {
                        if (onFinish && message != null) {
                            onFinish(message, {
                                usage,
                                finishReason
                            });
                        }
                    },
                    generateId: generateId2
                });
                return;
            }
        default:
            {
                const exhaustiveCheck = streamProtocol;
                throw new Error(`Unknown stream protocol: ${exhaustiveCheck}`);
            }
    }
}
// src/call-completion-api.ts
var getOriginalFetch2 = ()=>fetch;
async function callCompletionApi({ api, prompt, credentials, headers, body, streamProtocol = "data", setCompletion, setLoading, setError, setAbortController, onResponse, onFinish, onError, onData, fetch: fetch2 = getOriginalFetch2() }) {
    var _a;
    try {
        setLoading(true);
        setError(void 0);
        const abortController = new AbortController();
        setAbortController(abortController);
        setCompletion("");
        const response = await fetch2(api, {
            method: "POST",
            body: JSON.stringify({
                prompt,
                ...body
            }),
            credentials,
            headers: {
                "Content-Type": "application/json",
                ...headers
            },
            signal: abortController.signal
        }).catch((err)=>{
            throw err;
        });
        if (onResponse) {
            try {
                await onResponse(response);
            } catch (err) {
                throw err;
            }
        }
        if (!response.ok) {
            throw new Error((_a = await response.text()) != null ? _a : "Failed to fetch the chat response.");
        }
        if (!response.body) {
            throw new Error("The response body is empty.");
        }
        let result = "";
        switch(streamProtocol){
            case "text":
                {
                    await processTextStream({
                        stream: response.body,
                        onTextPart: (chunk)=>{
                            result += chunk;
                            setCompletion(result);
                        }
                    });
                    break;
                }
            case "data":
                {
                    await processDataStream({
                        stream: response.body,
                        onTextPart (value) {
                            result += value;
                            setCompletion(result);
                        },
                        onDataPart (value) {
                            onData == null ? void 0 : onData(value);
                        },
                        onErrorPart (value) {
                            throw new Error(value);
                        }
                    });
                    break;
                }
            default:
                {
                    const exhaustiveCheck = streamProtocol;
                    throw new Error(`Unknown stream protocol: ${exhaustiveCheck}`);
                }
        }
        if (onFinish) {
            onFinish(prompt, result);
        }
        setAbortController(null);
        return result;
    } catch (err) {
        if (err.name === "AbortError") {
            setAbortController(null);
            return null;
        }
        if (err instanceof Error) {
            if (onError) {
                onError(err);
            }
        }
        setError(err);
    } finally{
        setLoading(false);
    }
}
// src/data-url.ts
function getTextFromDataUrl(dataUrl) {
    const [header, base64Content] = dataUrl.split(",");
    const mimeType = header.split(";")[0].split(":")[1];
    if (mimeType == null || base64Content == null) {
        throw new Error("Invalid data URL format");
    }
    try {
        return window.atob(base64Content);
    } catch (error) {
        throw new Error(`Error decoding data URL`);
    }
}
// src/extract-max-tool-invocation-step.ts
function extractMaxToolInvocationStep(toolInvocations) {
    return toolInvocations == null ? void 0 : toolInvocations.reduce((max, toolInvocation)=>{
        var _a;
        return Math.max(max, (_a = toolInvocation.step) != null ? _a : 0);
    }, 0);
}
// src/get-message-parts.ts
function getMessageParts(message) {
    var _a;
    return (_a = message.parts) != null ? _a : [
        ...message.toolInvocations ? message.toolInvocations.map((toolInvocation)=>({
                type: "tool-invocation",
                toolInvocation
            })) : [],
        ...message.reasoning ? [
            {
                type: "reasoning",
                reasoning: message.reasoning,
                details: [
                    {
                        type: "text",
                        text: message.reasoning
                    }
                ]
            }
        ] : [],
        ...message.content ? [
            {
                type: "text",
                text: message.content
            }
        ] : []
    ];
}
// src/fill-message-parts.ts
function fillMessageParts(messages) {
    return messages.map((message)=>({
            ...message,
            parts: getMessageParts(message)
        }));
}
// src/is-deep-equal-data.ts
function isDeepEqualData(obj1, obj2) {
    if (obj1 === obj2) return true;
    if (obj1 == null || obj2 == null) return false;
    if (typeof obj1 !== "object" && typeof obj2 !== "object") return obj1 === obj2;
    if (obj1.constructor !== obj2.constructor) return false;
    if (obj1 instanceof Date && obj2 instanceof Date) {
        return obj1.getTime() === obj2.getTime();
    }
    if (Array.isArray(obj1)) {
        if (obj1.length !== obj2.length) return false;
        for(let i = 0; i < obj1.length; i++){
            if (!isDeepEqualData(obj1[i], obj2[i])) return false;
        }
        return true;
    }
    const keys1 = Object.keys(obj1);
    const keys2 = Object.keys(obj2);
    if (keys1.length !== keys2.length) return false;
    for (const key of keys1){
        if (!keys2.includes(key)) return false;
        if (!isDeepEqualData(obj1[key], obj2[key])) return false;
    }
    return true;
}
// src/prepare-attachments-for-request.ts
async function prepareAttachmentsForRequest(attachmentsFromOptions) {
    if (!attachmentsFromOptions) {
        return [];
    }
    if (globalThis.FileList && attachmentsFromOptions instanceof globalThis.FileList) {
        return Promise.all(Array.from(attachmentsFromOptions).map(async (attachment)=>{
            const { name, type } = attachment;
            const dataUrl = await new Promise((resolve, reject)=>{
                const reader = new FileReader();
                reader.onload = (readerEvent)=>{
                    var _a;
                    resolve((_a = readerEvent.target) == null ? void 0 : _a.result);
                };
                reader.onerror = (error)=>reject(error);
                reader.readAsDataURL(attachment);
            });
            return {
                name,
                contentType: type,
                url: dataUrl
            };
        }));
    }
    if (Array.isArray(attachmentsFromOptions)) {
        return attachmentsFromOptions;
    }
    throw new Error("Invalid attachments type");
}
// src/process-assistant-stream.ts
var NEWLINE2 = "\n".charCodeAt(0);
function concatChunks2(chunks, totalLength) {
    const concatenatedChunks = new Uint8Array(totalLength);
    let offset = 0;
    for (const chunk of chunks){
        concatenatedChunks.set(chunk, offset);
        offset += chunk.length;
    }
    chunks.length = 0;
    return concatenatedChunks;
}
async function processAssistantStream({ stream, onTextPart, onErrorPart, onAssistantMessagePart, onAssistantControlDataPart, onDataMessagePart }) {
    const reader = stream.getReader();
    const decoder = new TextDecoder();
    const chunks = [];
    let totalLength = 0;
    while(true){
        const { value } = await reader.read();
        if (value) {
            chunks.push(value);
            totalLength += value.length;
            if (value[value.length - 1] !== NEWLINE2) {
                continue;
            }
        }
        if (chunks.length === 0) {
            break;
        }
        const concatenatedChunks = concatChunks2(chunks, totalLength);
        totalLength = 0;
        const streamParts = decoder.decode(concatenatedChunks, {
            stream: true
        }).split("\n").filter((line)=>line !== "").map(parseAssistantStreamPart);
        for (const { type, value: value2 } of streamParts){
            switch(type){
                case "text":
                    await (onTextPart == null ? void 0 : onTextPart(value2));
                    break;
                case "error":
                    await (onErrorPart == null ? void 0 : onErrorPart(value2));
                    break;
                case "assistant_message":
                    await (onAssistantMessagePart == null ? void 0 : onAssistantMessagePart(value2));
                    break;
                case "assistant_control_data":
                    await (onAssistantControlDataPart == null ? void 0 : onAssistantControlDataPart(value2));
                    break;
                case "data_message":
                    await (onDataMessagePart == null ? void 0 : onDataMessagePart(value2));
                    break;
                default:
                    {
                        const exhaustiveCheck = type;
                        throw new Error(`Unknown stream part type: ${exhaustiveCheck}`);
                    }
            }
        }
    }
}
;
;
function zodSchema(zodSchema2, options) {
    var _a;
    const useReferences = (_a = options == null ? void 0 : options.useReferences) != null ? _a : false;
    return jsonSchema((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2d$to$2d$json$2d$schema$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["default"])(zodSchema2, {
        $refStrategy: useReferences ? "root" : "none",
        target: "jsonSchema7"
    }), {
        validate: (value)=>{
            const result = zodSchema2.safeParse(value);
            return result.success ? {
                success: true,
                value: result.data
            } : {
                success: false,
                error: result.error
            };
        }
    });
}
// src/schema.ts
var schemaSymbol = Symbol.for("vercel.ai.schema");
function jsonSchema(jsonSchema2, { validate } = {}) {
    return {
        [schemaSymbol]: true,
        _type: void 0,
        // should never be used directly
        [__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validatorSymbol"]]: true,
        jsonSchema: jsonSchema2,
        validate
    };
}
function isSchema(value) {
    return typeof value === "object" && value !== null && schemaSymbol in value && value[schemaSymbol] === true && "jsonSchema" in value && "validate" in value;
}
function asSchema(schema) {
    return isSchema(schema) ? schema : zodSchema(schema);
}
// src/should-resubmit-messages.ts
function shouldResubmitMessages({ originalMaxToolInvocationStep, originalMessageCount, maxSteps, messages }) {
    var _a;
    const lastMessage = messages[messages.length - 1];
    return(// check if the feature is enabled:
    maxSteps > 1 && // ensure there is a last message:
    lastMessage != null && // ensure we actually have new steps (to prevent infinite loops in case of errors):
    (messages.length > originalMessageCount || extractMaxToolInvocationStep(lastMessage.toolInvocations) !== originalMaxToolInvocationStep) && // check that next step is possible:
    isAssistantMessageWithCompletedToolCalls(lastMessage) && // limit the number of automatic steps:
    ((_a = extractMaxToolInvocationStep(lastMessage.toolInvocations)) != null ? _a : 0) < maxSteps);
}
function isAssistantMessageWithCompletedToolCalls(message) {
    if (message.role !== "assistant") {
        return false;
    }
    const lastStepStartIndex = message.parts.reduce((lastIndex, part, index)=>{
        return part.type === "step-start" ? index : lastIndex;
    }, -1);
    const lastStepToolInvocations = message.parts.slice(lastStepStartIndex + 1).filter((part)=>part.type === "tool-invocation");
    return lastStepToolInvocations.length > 0 && lastStepToolInvocations.every((part)=>"result" in part.toolInvocation);
}
// src/update-tool-call-result.ts
function updateToolCallResult({ messages, toolCallId, toolResult: result }) {
    var _a;
    const lastMessage = messages[messages.length - 1];
    const invocationPart = lastMessage.parts.find((part)=>part.type === "tool-invocation" && part.toolInvocation.toolCallId === toolCallId);
    if (invocationPart == null) {
        return;
    }
    const toolResult = {
        ...invocationPart.toolInvocation,
        state: "result",
        result
    };
    invocationPart.toolInvocation = toolResult;
    lastMessage.toolInvocations = (_a = lastMessage.toolInvocations) == null ? void 0 : _a.map((toolInvocation)=>toolInvocation.toolCallId === toolCallId ? toolResult : toolInvocation);
}
;
 //# sourceMappingURL=index.mjs.map
}}),
"[project]/node_modules/@ai-sdk/react/dist/index.mjs [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
// src/use-assistant.ts
__turbopack_context__.s({
    "experimental_useObject": (()=>experimental_useObject),
    "useAssistant": (()=>useAssistant),
    "useChat": (()=>useChat),
    "useCompletion": (()=>useCompletion)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@ai-sdk/provider-utils/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$ui$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@ai-sdk/ui-utils/dist/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$swr$2f$dist$2f$index$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/swr/dist/index/index.mjs [app-client] (ecmascript) <locals>");
// src/throttle.ts
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$throttleit$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/throttleit/index.js [app-client] (ecmascript)");
;
;
;
var getOriginalFetch = ()=>fetch;
function useAssistant({ api, threadId: threadIdParam, credentials, headers, body, onError, fetch: fetch2 }) {
    const [messages, setMessages] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [input, setInput] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [currentThreadId, setCurrentThreadId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(void 0);
    const [status, setStatus] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("awaiting_message");
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(void 0);
    const handleInputChange = (event)=>{
        setInput(event.target.value);
    };
    const abortControllerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const stop = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useAssistant.useCallback[stop]": ()=>{
            if (abortControllerRef.current) {
                abortControllerRef.current.abort();
                abortControllerRef.current = null;
            }
        }
    }["useAssistant.useCallback[stop]"], []);
    const append = async (message, requestOptions)=>{
        var _a, _b;
        setStatus("in_progress");
        setMessages((messages2)=>{
            var _a2;
            return [
                ...messages2,
                {
                    ...message,
                    id: (_a2 = message.id) != null ? _a2 : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["generateId"])()
                }
            ];
        });
        setInput("");
        const abortController = new AbortController();
        try {
            abortControllerRef.current = abortController;
            const actualFetch = fetch2 != null ? fetch2 : getOriginalFetch();
            const response = await actualFetch(api, {
                method: "POST",
                credentials,
                signal: abortController.signal,
                headers: {
                    "Content-Type": "application/json",
                    ...headers
                },
                body: JSON.stringify({
                    ...body,
                    // always use user-provided threadId when available:
                    threadId: (_a = threadIdParam != null ? threadIdParam : currentThreadId) != null ? _a : null,
                    message: message.content,
                    // optional request data:
                    data: requestOptions == null ? void 0 : requestOptions.data
                })
            });
            if (!response.ok) {
                throw new Error((_b = await response.text()) != null ? _b : "Failed to fetch the assistant response.");
            }
            if (response.body == null) {
                throw new Error("The response body is empty.");
            }
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$ui$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["processAssistantStream"])({
                stream: response.body,
                onAssistantMessagePart (value) {
                    setMessages((messages2)=>[
                            ...messages2,
                            {
                                id: value.id,
                                role: value.role,
                                content: value.content[0].text.value,
                                parts: []
                            }
                        ]);
                },
                onTextPart (value) {
                    setMessages((messages2)=>{
                        const lastMessage = messages2[messages2.length - 1];
                        return [
                            ...messages2.slice(0, messages2.length - 1),
                            {
                                id: lastMessage.id,
                                role: lastMessage.role,
                                content: lastMessage.content + value,
                                parts: lastMessage.parts
                            }
                        ];
                    });
                },
                onAssistantControlDataPart (value) {
                    setCurrentThreadId(value.threadId);
                    setMessages((messages2)=>{
                        const lastMessage = messages2[messages2.length - 1];
                        lastMessage.id = value.messageId;
                        return [
                            ...messages2.slice(0, messages2.length - 1),
                            lastMessage
                        ];
                    });
                },
                onDataMessagePart (value) {
                    setMessages((messages2)=>{
                        var _a2;
                        return [
                            ...messages2,
                            {
                                id: (_a2 = value.id) != null ? _a2 : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["generateId"])(),
                                role: "data",
                                content: "",
                                data: value.data,
                                parts: []
                            }
                        ];
                    });
                },
                onErrorPart (value) {
                    setError(new Error(value));
                }
            });
        } catch (error2) {
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isAbortError"])(error2) && abortController.signal.aborted) {
                abortControllerRef.current = null;
                return;
            }
            if (onError && error2 instanceof Error) {
                onError(error2);
            }
            setError(error2);
        } finally{
            abortControllerRef.current = null;
            setStatus("awaiting_message");
        }
    };
    const submitMessage = async (event, requestOptions)=>{
        var _a;
        (_a = event == null ? void 0 : event.preventDefault) == null ? void 0 : _a.call(event);
        if (input === "") {
            return;
        }
        append({
            role: "user",
            content: input,
            parts: []
        }, requestOptions);
    };
    const setThreadId = (threadId)=>{
        setCurrentThreadId(threadId);
        setMessages([]);
    };
    return {
        append,
        messages,
        setMessages,
        threadId: currentThreadId,
        setThreadId,
        input,
        setInput,
        handleInputChange,
        submitMessage,
        status,
        error,
        stop
    };
}
;
;
;
;
function throttle(fn, waitMs) {
    return waitMs != null ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$throttleit$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(fn, waitMs) : fn;
}
;
;
function useStableValue(latestValue) {
    const [value, setValue] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(latestValue);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useStableValue.useEffect": ()=>{
            if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$ui$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["isDeepEqualData"])(latestValue, value)) {
                setValue(latestValue);
            }
        }
    }["useStableValue.useEffect"], [
        latestValue,
        value
    ]);
    return value;
}
// src/use-chat.ts
function useChat({ api = "/api/chat", id, initialMessages, initialInput = "", sendExtraMessageFields, onToolCall, experimental_prepareRequestBody, maxSteps = 1, streamProtocol = "data", onResponse, onFinish, onError, credentials, headers, body, generateId: generateId2 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["generateId"], fetch: fetch2, keepLastMessageOnError = true, experimental_throttle: throttleWaitMs } = {}) {
    const [hookId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(generateId2);
    const chatId = id != null ? id : hookId;
    const chatKey = typeof api === "string" ? [
        api,
        chatId
    ] : chatId;
    const stableInitialMessages = useStableValue(initialMessages != null ? initialMessages : []);
    const processedInitialMessages = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "useChat.useMemo[processedInitialMessages]": ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$ui$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["fillMessageParts"])(stableInitialMessages)
    }["useChat.useMemo[processedInitialMessages]"], [
        stableInitialMessages
    ]);
    const { data: messages, mutate } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$swr$2f$dist$2f$index$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["default"])([
        chatKey,
        "messages"
    ], null, {
        fallbackData: processedInitialMessages
    });
    const messagesRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(messages || []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useChat.useEffect2": ()=>{
            messagesRef.current = messages || [];
        }
    }["useChat.useEffect2"], [
        messages
    ]);
    const { data: streamData, mutate: mutateStreamData } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$swr$2f$dist$2f$index$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["default"])([
        chatKey,
        "streamData"
    ], null);
    const streamDataRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(streamData);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useChat.useEffect2": ()=>{
            streamDataRef.current = streamData;
        }
    }["useChat.useEffect2"], [
        streamData
    ]);
    const { data: status = "ready", mutate: mutateStatus } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$swr$2f$dist$2f$index$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["default"])([
        chatKey,
        "status"
    ], null);
    const { data: error = void 0, mutate: setError } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$swr$2f$dist$2f$index$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["default"])([
        chatKey,
        "error"
    ], null);
    const abortControllerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const extraMetadataRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])({
        credentials,
        headers,
        body
    });
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useChat.useEffect2": ()=>{
            extraMetadataRef.current = {
                credentials,
                headers,
                body
            };
        }
    }["useChat.useEffect2"], [
        credentials,
        headers,
        body
    ]);
    const triggerRequest = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useChat.useCallback2[triggerRequest]": async (chatRequest, requestType = "generate")=>{
            var _a, _b;
            mutateStatus("submitted");
            setError(void 0);
            const chatMessages = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$ui$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["fillMessageParts"])(chatRequest.messages);
            const messageCount = chatMessages.length;
            const maxStep = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$ui$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["extractMaxToolInvocationStep"])((_a = chatMessages[chatMessages.length - 1]) == null ? void 0 : _a.toolInvocations);
            try {
                const abortController = new AbortController();
                abortControllerRef.current = abortController;
                const throttledMutate = throttle(mutate, throttleWaitMs);
                const throttledMutateStreamData = throttle(mutateStreamData, throttleWaitMs);
                const previousMessages = messagesRef.current;
                throttledMutate(chatMessages, false);
                const constructedMessagesPayload = sendExtraMessageFields ? chatMessages : chatMessages.map({
                    "useChat.useCallback2[triggerRequest]": ({ role, content, experimental_attachments, data, annotations, toolInvocations, parts })=>({
                            role,
                            content,
                            ...experimental_attachments !== void 0 && {
                                experimental_attachments
                            },
                            ...data !== void 0 && {
                                data
                            },
                            ...annotations !== void 0 && {
                                annotations
                            },
                            ...toolInvocations !== void 0 && {
                                toolInvocations
                            },
                            ...parts !== void 0 && {
                                parts
                            }
                        })
                }["useChat.useCallback2[triggerRequest]"]);
                const existingData = streamDataRef.current;
                await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$ui$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["callChatApi"])({
                    api,
                    body: (_b = experimental_prepareRequestBody == null ? void 0 : experimental_prepareRequestBody({
                        id: chatId,
                        messages: chatMessages,
                        requestData: chatRequest.data,
                        requestBody: chatRequest.body
                    })) != null ? _b : {
                        id: chatId,
                        messages: constructedMessagesPayload,
                        data: chatRequest.data,
                        ...extraMetadataRef.current.body,
                        ...chatRequest.body
                    },
                    streamProtocol,
                    credentials: extraMetadataRef.current.credentials,
                    headers: {
                        ...extraMetadataRef.current.headers,
                        ...chatRequest.headers
                    },
                    abortController: {
                        "useChat.useCallback2[triggerRequest]": ()=>abortControllerRef.current
                    }["useChat.useCallback2[triggerRequest]"],
                    restoreMessagesOnFailure () {
                        if (!keepLastMessageOnError) {
                            throttledMutate(previousMessages, false);
                        }
                    },
                    onResponse,
                    onUpdate ({ message, data, replaceLastMessage }) {
                        mutateStatus("streaming");
                        throttledMutate([
                            ...replaceLastMessage ? chatMessages.slice(0, chatMessages.length - 1) : chatMessages,
                            message
                        ], false);
                        if (data == null ? void 0 : data.length) {
                            throttledMutateStreamData([
                                ...existingData != null ? existingData : [],
                                ...data
                            ], false);
                        }
                    },
                    onToolCall,
                    onFinish,
                    generateId: generateId2,
                    fetch: fetch2,
                    lastMessage: chatMessages[chatMessages.length - 1],
                    requestType
                });
                abortControllerRef.current = null;
                mutateStatus("ready");
            } catch (err) {
                if (err.name === "AbortError") {
                    abortControllerRef.current = null;
                    mutateStatus("ready");
                    return null;
                }
                if (onError && err instanceof Error) {
                    onError(err);
                }
                setError(err);
                mutateStatus("error");
            }
            const messages2 = messagesRef.current;
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$ui$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["shouldResubmitMessages"])({
                originalMaxToolInvocationStep: maxStep,
                originalMessageCount: messageCount,
                maxSteps,
                messages: messages2
            })) {
                await triggerRequest({
                    messages: messages2
                });
            }
        }
    }["useChat.useCallback2[triggerRequest]"], [
        mutate,
        mutateStatus,
        api,
        extraMetadataRef,
        onResponse,
        onFinish,
        onError,
        setError,
        mutateStreamData,
        streamDataRef,
        streamProtocol,
        sendExtraMessageFields,
        experimental_prepareRequestBody,
        onToolCall,
        maxSteps,
        messagesRef,
        abortControllerRef,
        generateId2,
        fetch2,
        keepLastMessageOnError,
        throttleWaitMs,
        chatId
    ]);
    const append = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useChat.useCallback2[append]": async (message, { data, headers: headers2, body: body2, experimental_attachments = message.experimental_attachments } = {})=>{
            var _a, _b;
            const attachmentsForRequest = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$ui$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["prepareAttachmentsForRequest"])(experimental_attachments);
            const messages2 = messagesRef.current.concat({
                ...message,
                id: (_a = message.id) != null ? _a : generateId2(),
                createdAt: (_b = message.createdAt) != null ? _b : /* @__PURE__ */ new Date(),
                experimental_attachments: attachmentsForRequest.length > 0 ? attachmentsForRequest : void 0,
                parts: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$ui$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["getMessageParts"])(message)
            });
            return triggerRequest({
                messages: messages2,
                headers: headers2,
                body: body2,
                data
            });
        }
    }["useChat.useCallback2[append]"], [
        triggerRequest,
        generateId2
    ]);
    const reload = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useChat.useCallback2[reload]": async ({ data, headers: headers2, body: body2 } = {})=>{
            const messages2 = messagesRef.current;
            if (messages2.length === 0) {
                return null;
            }
            const lastMessage = messages2[messages2.length - 1];
            return triggerRequest({
                messages: lastMessage.role === "assistant" ? messages2.slice(0, -1) : messages2,
                headers: headers2,
                body: body2,
                data
            });
        }
    }["useChat.useCallback2[reload]"], [
        triggerRequest
    ]);
    const stop = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useChat.useCallback2[stop]": ()=>{
            if (abortControllerRef.current) {
                abortControllerRef.current.abort();
                abortControllerRef.current = null;
            }
        }
    }["useChat.useCallback2[stop]"], []);
    const experimental_resume = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useChat.useCallback2[experimental_resume]": async ()=>{
            const messages2 = messagesRef.current;
            triggerRequest({
                messages: messages2
            }, "resume");
        }
    }["useChat.useCallback2[experimental_resume]"], [
        triggerRequest
    ]);
    const setMessages = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useChat.useCallback2[setMessages]": (messages2)=>{
            if (typeof messages2 === "function") {
                messages2 = messages2(messagesRef.current);
            }
            const messagesWithParts = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$ui$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["fillMessageParts"])(messages2);
            mutate(messagesWithParts, false);
            messagesRef.current = messagesWithParts;
        }
    }["useChat.useCallback2[setMessages]"], [
        mutate
    ]);
    const setData = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useChat.useCallback2[setData]": (data)=>{
            if (typeof data === "function") {
                data = data(streamDataRef.current);
            }
            mutateStreamData(data, false);
            streamDataRef.current = data;
        }
    }["useChat.useCallback2[setData]"], [
        mutateStreamData
    ]);
    const [input, setInput] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(initialInput);
    const handleSubmit = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useChat.useCallback2[handleSubmit]": async (event, options = {}, metadata)=>{
            var _a;
            (_a = event == null ? void 0 : event.preventDefault) == null ? void 0 : _a.call(event);
            if (!input && !options.allowEmptySubmit) return;
            if (metadata) {
                extraMetadataRef.current = {
                    ...extraMetadataRef.current,
                    ...metadata
                };
            }
            const attachmentsForRequest = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$ui$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["prepareAttachmentsForRequest"])(options.experimental_attachments);
            const messages2 = messagesRef.current.concat({
                id: generateId2(),
                createdAt: /* @__PURE__ */ new Date(),
                role: "user",
                content: input,
                experimental_attachments: attachmentsForRequest.length > 0 ? attachmentsForRequest : void 0,
                parts: [
                    {
                        type: "text",
                        text: input
                    }
                ]
            });
            const chatRequest = {
                messages: messages2,
                headers: options.headers,
                body: options.body,
                data: options.data
            };
            triggerRequest(chatRequest);
            setInput("");
        }
    }["useChat.useCallback2[handleSubmit]"], [
        input,
        generateId2,
        triggerRequest
    ]);
    const handleInputChange = (e)=>{
        setInput(e.target.value);
    };
    const addToolResult = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useChat.useCallback2[addToolResult]": ({ toolCallId, result })=>{
            const currentMessages = messagesRef.current;
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$ui$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["updateToolCallResult"])({
                messages: currentMessages,
                toolCallId,
                toolResult: result
            });
            mutate([
                ...currentMessages.slice(0, currentMessages.length - 1),
                {
                    ...currentMessages[currentMessages.length - 1]
                }
            ], false);
            if (status === "submitted" || status === "streaming") {
                return;
            }
            const lastMessage = currentMessages[currentMessages.length - 1];
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$ui$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["isAssistantMessageWithCompletedToolCalls"])(lastMessage)) {
                triggerRequest({
                    messages: currentMessages
                });
            }
        }
    }["useChat.useCallback2[addToolResult]"], [
        mutate,
        status,
        triggerRequest
    ]);
    return {
        messages: messages != null ? messages : [],
        id: chatId,
        setMessages,
        data: streamData,
        setData,
        error,
        append,
        reload,
        stop,
        experimental_resume,
        input,
        setInput,
        handleInputChange,
        handleSubmit,
        isLoading: status === "submitted" || status === "streaming",
        status,
        addToolResult
    };
}
;
;
;
function useCompletion({ api = "/api/completion", id, initialCompletion = "", initialInput = "", credentials, headers, body, streamProtocol = "data", fetch: fetch2, onResponse, onFinish, onError, experimental_throttle: throttleWaitMs } = {}) {
    const hookId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"])();
    const completionId = id || hookId;
    const { data, mutate } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$swr$2f$dist$2f$index$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["default"])([
        api,
        completionId
    ], null, {
        fallbackData: initialCompletion
    });
    const { data: isLoading = false, mutate: mutateLoading } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$swr$2f$dist$2f$index$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["default"])([
        completionId,
        "loading"
    ], null);
    const { data: streamData, mutate: mutateStreamData } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$swr$2f$dist$2f$index$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["default"])([
        completionId,
        "streamData"
    ], null);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(void 0);
    const completion = data;
    const [abortController, setAbortController] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const extraMetadataRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])({
        credentials,
        headers,
        body
    });
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useCompletion.useEffect3": ()=>{
            extraMetadataRef.current = {
                credentials,
                headers,
                body
            };
        }
    }["useCompletion.useEffect3"], [
        credentials,
        headers,
        body
    ]);
    const triggerRequest = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useCompletion.useCallback3[triggerRequest]": async (prompt, options)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$ui$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["callCompletionApi"])({
                api,
                prompt,
                credentials: extraMetadataRef.current.credentials,
                headers: {
                    ...extraMetadataRef.current.headers,
                    ...options == null ? void 0 : options.headers
                },
                body: {
                    ...extraMetadataRef.current.body,
                    ...options == null ? void 0 : options.body
                },
                streamProtocol,
                fetch: fetch2,
                // throttle streamed ui updates:
                setCompletion: throttle({
                    "useCompletion.useCallback3[triggerRequest]": (completion2)=>mutate(completion2, false)
                }["useCompletion.useCallback3[triggerRequest]"], throttleWaitMs),
                onData: throttle({
                    "useCompletion.useCallback3[triggerRequest]": (data2)=>mutateStreamData([
                            ...streamData != null ? streamData : [],
                            ...data2 != null ? data2 : []
                        ], false)
                }["useCompletion.useCallback3[triggerRequest]"], throttleWaitMs),
                setLoading: mutateLoading,
                setError,
                setAbortController,
                onResponse,
                onFinish,
                onError
            })
    }["useCompletion.useCallback3[triggerRequest]"], [
        mutate,
        mutateLoading,
        api,
        extraMetadataRef,
        setAbortController,
        onResponse,
        onFinish,
        onError,
        setError,
        streamData,
        streamProtocol,
        fetch2,
        mutateStreamData,
        throttleWaitMs
    ]);
    const stop = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useCompletion.useCallback3[stop]": ()=>{
            if (abortController) {
                abortController.abort();
                setAbortController(null);
            }
        }
    }["useCompletion.useCallback3[stop]"], [
        abortController
    ]);
    const setCompletion = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useCompletion.useCallback3[setCompletion]": (completion2)=>{
            mutate(completion2, false);
        }
    }["useCompletion.useCallback3[setCompletion]"], [
        mutate
    ]);
    const complete = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useCompletion.useCallback3[complete]": async (prompt, options)=>{
            return triggerRequest(prompt, options);
        }
    }["useCompletion.useCallback3[complete]"], [
        triggerRequest
    ]);
    const [input, setInput] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(initialInput);
    const handleSubmit = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useCompletion.useCallback3[handleSubmit]": (event)=>{
            var _a;
            (_a = event == null ? void 0 : event.preventDefault) == null ? void 0 : _a.call(event);
            return input ? complete(input) : void 0;
        }
    }["useCompletion.useCallback3[handleSubmit]"], [
        input,
        complete
    ]);
    const handleInputChange = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useCompletion.useCallback3[handleInputChange]": (e)=>{
            setInput(e.target.value);
        }
    }["useCompletion.useCallback3[handleInputChange]"], [
        setInput
    ]);
    return {
        completion,
        complete,
        error,
        setCompletion,
        stop,
        input,
        setInput,
        handleInputChange,
        handleSubmit,
        isLoading,
        data: streamData
    };
}
;
;
;
;
var getOriginalFetch2 = ()=>fetch;
function useObject({ api, id, schema, // required, in the future we will use it for validation
initialValue, fetch: fetch2, onError, onFinish, headers, credentials }) {
    const hookId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"])();
    const completionId = id != null ? id : hookId;
    const { data, mutate } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$swr$2f$dist$2f$index$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["default"])([
        api,
        completionId
    ], null, {
        fallbackData: initialValue
    });
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(void 0);
    const [isLoading, setIsLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const abortControllerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const stop = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useObject.useCallback4[stop]": ()=>{
            var _a;
            try {
                (_a = abortControllerRef.current) == null ? void 0 : _a.abort();
            } catch (ignored) {} finally{
                setIsLoading(false);
                abortControllerRef.current = null;
            }
        }
    }["useObject.useCallback4[stop]"], []);
    const submit = async (input)=>{
        var _a;
        try {
            mutate(void 0);
            setIsLoading(true);
            setError(void 0);
            const abortController = new AbortController();
            abortControllerRef.current = abortController;
            const actualFetch = fetch2 != null ? fetch2 : getOriginalFetch2();
            const response = await actualFetch(api, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    ...headers
                },
                credentials,
                signal: abortController.signal,
                body: JSON.stringify(input)
            });
            if (!response.ok) {
                throw new Error((_a = await response.text()) != null ? _a : "Failed to fetch the response.");
            }
            if (response.body == null) {
                throw new Error("The response body is empty.");
            }
            let accumulatedText = "";
            let latestObject = void 0;
            await response.body.pipeThrough(new TextDecoderStream()).pipeTo(new WritableStream({
                write (chunk) {
                    accumulatedText += chunk;
                    const { value } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$ui$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["parsePartialJson"])(accumulatedText);
                    const currentObject = value;
                    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$ui$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["isDeepEqualData"])(latestObject, currentObject)) {
                        latestObject = currentObject;
                        mutate(currentObject);
                    }
                },
                close () {
                    setIsLoading(false);
                    abortControllerRef.current = null;
                    if (onFinish != null) {
                        const validationResult = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["safeValidateTypes"])({
                            value: latestObject,
                            schema: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$ui$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["asSchema"])(schema)
                        });
                        onFinish(validationResult.success ? {
                            object: validationResult.value,
                            error: void 0
                        } : {
                            object: void 0,
                            error: validationResult.error
                        });
                    }
                }
            }));
        } catch (error2) {
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isAbortError"])(error2)) {
                return;
            }
            if (onError && error2 instanceof Error) {
                onError(error2);
            }
            setIsLoading(false);
            setError(error2 instanceof Error ? error2 : new Error(String(error2)));
        }
    };
    return {
        submit,
        object: data,
        error,
        isLoading,
        stop
    };
}
var experimental_useObject = useObject;
;
 //# sourceMappingURL=index.mjs.map
}}),
}]);

//# sourceMappingURL=node_modules_%40ai-sdk_2665e7c3._.js.map